import { explainAppError } from "../core/errors.js";
import {
  geocodeCityName,
  reverseGeocodeLocation,
  stringifyCoordinateStorage,
} from "../core/geocoding.js";
import { getBestAvailableLocation } from "../core/location.js";
import { getDashboardPath, bootstrapPage, consumeNextRoute } from "../core/shell.js";
import { login, register } from "../core/store.js";
import { showToast } from "../core/ui.js";

document.addEventListener("DOMContentLoaded", async () => {
  const { user } = await bootstrapPage({ currentPage: "login" });
  if (user) {
    window.location.href = getDashboardPath(user.role);
    return;
  }

  const nextRoute = consumeNextRoute();
  const tabButtons = Array.from(document.querySelectorAll("[data-auth-tab]"));
  const panels = Array.from(document.querySelectorAll("[data-auth-panel]"));
  const roleSelect = document.getElementById("register-role");
  const registerPanels = Array.from(document.querySelectorAll("[data-role-panel]"));
  const loginForm = document.getElementById("login-form");
  const registerForm = document.getElementById("register-form");

  function switchTab(target) {
    tabButtons.forEach((button) => {
      button.classList.toggle("active", button.dataset.authTab === target);
    });

    panels.forEach((panel) => {
      panel.hidden = panel.dataset.authPanel !== target;
    });
  }

  function switchRole(role) {
    registerPanels.forEach((panel) => {
      const isActive = panel.dataset.rolePanel === role;
      panel.classList.toggle("hidden", !isActive);
      panel.querySelectorAll("input, select, textarea").forEach((field) => {
        field.disabled = !isActive;
      });
    });
  }

  function collectRoleFormValues(role) {
    const panel = document.querySelector(`[data-role-panel="${role}"]`);
    const data = Object.fromEntries(
      Array.from(panel.querySelectorAll("input, select, textarea")).map((field) => [
        field.name,
        field.value.trim(),
      ])
    );

    return { role, ...data };
  }

  async function resolvePanelLocation(role) {
    const panel = document.querySelector(`[data-role-panel="${role}"]`);
    if (!panel) {
      return;
    }

    const labelField = panel.querySelector('[name="locationLabel"]');
    const coordsField = panel.querySelector('[name="currentLocation"]');
    if (!labelField || !coordsField) {
      return;
    }

    const hasCoords = coordsField.value.trim();
    const label = labelField.value.trim();

    if (!label || hasCoords) {
      return;
    }

    const result = await geocodeCityName(label);
    labelField.value = result.label || label;
    coordsField.value = result.currentLocation;
  }

  function redirectAfterAuth(nextUser) {
    const target =
      nextRoute && !nextRoute.includes("login.html") ? nextRoute : getDashboardPath(nextUser.role);
    window.location.href = target;
  }

  tabButtons.forEach((button) => {
    button.addEventListener("click", () => switchTab(button.dataset.authTab));
  });

  roleSelect.addEventListener("change", () => switchRole(roleSelect.value));
  switchRole(roleSelect.value);

  document.querySelectorAll('input[name="locationLabel"]').forEach((field) => {
    field.addEventListener("input", () => {
      const coordsField = document.querySelector(field.dataset.coordinates || "");
      if (coordsField) {
        coordsField.value = "";
      }
    });
  });

  loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    try {
      const formData = new FormData(loginForm);
      const nextUser = await login(formData.get("email"), formData.get("password"));
      showToast("Signed in successfully.", "success");
      redirectAfterAuth(nextUser);
    } catch (error) {
      showToast(explainAppError(error), "error");
    }
  });

  registerForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    try {
      const role = roleSelect.value;
      await resolvePanelLocation(role);
      const payload = collectRoleFormValues(role);
      if (!payload.email || !payload.password) {
        throw new Error("Email and password are required.");
      }

      const nextUser = await register(role, payload);
      showToast("Account created successfully.", "success");
      redirectAfterAuth(nextUser);
    } catch (error) {
      showToast(explainAppError(error), "error");
    }
  });

  document.querySelectorAll("[data-find-location]").forEach((button) => {
    button.addEventListener("click", async () => {
      const labelField = document.querySelector(button.dataset.target);
      const coordsField = document.querySelector(button.dataset.coordinates);
      if (!labelField || !coordsField) {
        return;
      }

      try {
        const result = await geocodeCityName(labelField.value);
        labelField.value = result.label || labelField.value.trim();
        coordsField.value = result.currentLocation;
        showToast("City located on the map successfully.", "success");
      } catch (error) {
        showToast(explainAppError(error), "error");
      }
    });
  });

  document.querySelectorAll("[data-capture-location]").forEach((button) => {
    button.addEventListener("click", async () => {
      const labelField = document.querySelector(button.dataset.target);
      const coordsField = document.querySelector(button.dataset.coordinates);
      if (!labelField || !coordsField) {
        return;
      }

      try {
        const location = await getBestAvailableLocation({ warmupTimeoutMs: 28000 });
        const reverse = await reverseGeocodeLocation(location);
        labelField.value = reverse?.label || "Current GPS location";
        coordsField.value = stringifyCoordinateStorage(location);
        showToast("Location captured from device GPS.", "success");
      } catch (error) {
        showToast(explainAppError(error), "error");
      }
    });
  });
});
