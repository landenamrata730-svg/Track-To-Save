import { buildSmartRoute, pickTrafficLevel } from "./utils.js";

const OSRM_ROUTE_ENDPOINT = "https://router.project-osrm.org/route/v1/driving";
const OSRM_NEAREST_ENDPOINT = "https://router.project-osrm.org/nearest/v1/driving";
const MAX_SNAP_DISTANCE_METERS = 180;

function applyTrafficToDuration(baseDurationMinutes, trafficLevel) {
  const multiplier =
    trafficLevel === "heavy" ? 1.45 : trafficLevel === "moderate" ? 1.2 : 1.05;
  return Math.max(2, Math.round(baseDurationMinutes * multiplier));
}

function toCoordinateString(location) {
  return `${location.lng},${location.lat}`;
}

function toRoutePoint(location) {
  return { lat: Number(location.lat), lng: Number(location.lng) };
}

function toWaypointLocation(waypoint) {
  if (!waypoint?.location?.length) {
    return null;
  }

  return {
    lat: Number(waypoint.location[1]),
    lng: Number(waypoint.location[0]),
    distanceMeters: Number(waypoint.distance || 0),
  };
}

async function fetchJson(url) {
  const response = await fetch(url.toString(), {
    headers: {
      Accept: "application/json",
    },
  });

  if (!response.ok) {
    throw new Error("Route service unavailable.");
  }

  return response.json();
}

async function snapPointToNearestRoad(location) {
  if (!location || typeof fetch === "undefined") {
    return toRoutePoint(location);
  }

  const url = new URL(`${OSRM_NEAREST_ENDPOINT}/${toCoordinateString(location)}`);
  url.searchParams.set("number", "1");

  try {
    const payload = await fetchJson(url);
    const waypoint = toWaypointLocation(payload?.waypoints?.[0]);

    if (!waypoint || waypoint.distanceMeters > MAX_SNAP_DISTANCE_METERS) {
      return toRoutePoint(location);
    }

    return {
      lat: waypoint.lat,
      lng: waypoint.lng,
    };
  } catch (error) {
    return toRoutePoint(location);
  }
}

export async function getSmartRoute(start, end) {
  const fallback = buildSmartRoute(start, end);

  if (!start || !end || typeof fetch === "undefined") {
    return fallback;
  }

  try {
    const [routeStart, routeEnd] = await Promise.all([
      snapPointToNearestRoad(start),
      snapPointToNearestRoad(end),
    ]);

    const url = new URL(
      `${OSRM_ROUTE_ENDPOINT}/${toCoordinateString(routeStart)};${toCoordinateString(routeEnd)}`
    );
    url.searchParams.set("overview", "full");
    url.searchParams.set("geometries", "geojson");
    url.searchParams.set("steps", "false");
    url.searchParams.set("alternatives", "true");

    const payload = await fetchJson(url);
    const route = payload?.routes?.[0];

    if (!route?.geometry?.coordinates?.length) {
      return fallback;
    }

    const distanceKm = Number((route.distance / 1000).toFixed(2));
    const trafficLevel = pickTrafficLevel(distanceKm);
    const routePath = route.geometry.coordinates.map(([lng, lat]) => ({ lat, lng }));

    return {
      routePath,
      trafficLevel,
      distanceKm,
      etaMinutes: applyTrafficToDuration(route.duration / 60, trafficLevel),
      routeStart,
      routeEnd,
      routeEngine: "osrm-road-snap",
    };
  } catch (error) {
    return fallback;
  }
}
