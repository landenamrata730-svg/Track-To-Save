import {
  capitalizeWords,
  escapeHtml,
  formatDateTime,
  formatEta,
  stringifyLocation,
} from "./utils.js";

export function toneForStatus(status = "") {
  if (["completed", "available", "prepared", "low"].includes(status)) {
    return "tone-success";
  }

  if (["arrived", "moderate", "on_trip"].includes(status)) {
    return "tone-warning";
  }

  if (["heavy", "offline", "emergency_mode"].includes(status)) {
    return "tone-danger";
  }

  return "tone-info";
}

export function renderStatCards(container, items = []) {
  if (!container) {
    return;
  }

  container.innerHTML = items
    .map(
      (item) => `
        <article class="stat-card">
          <div class="stat-header">
            <h3>${escapeHtml(item.label)}</h3>
            ${item.badge ? `<span class="status-badge ${item.badgeTone || "tone-info"}">${escapeHtml(item.badge)}</span>` : ""}
          </div>
          <strong class="stat-value">${escapeHtml(String(item.value ?? 0))}</strong>
          ${item.helper ? `<p class="stat-label">${escapeHtml(item.helper)}</p>` : ""}
        </article>
      `
    )
    .join("");
}

export function renderEmergencySummary(emergency, options = {}) {
  if (!emergency) {
    return `
      <div class="empty-state">
        <h3>No live emergency</h3>
        <p>${escapeHtml(options.emptyMessage || "There is no active emergency to show right now.")}</p>
      </div>
    `;
  }

  return `
    <div class="content-flow">
      <div class="card-title-row">
        <div>
          <h3>${escapeHtml(options.title || "Active emergency")}</h3>
          <p class="muted-text">Tracking ID ${escapeHtml(emergency.trackingId || "Pending")}</p>
        </div>
        <span class="status-badge ${toneForStatus(emergency.status)}">${escapeHtml(
          capitalizeWords(emergency.status)
        )}</span>
      </div>
      <div class="key-value-grid">
        <div class="key-value">
          <strong>Driver</strong>
          <span>${escapeHtml(emergency.driverName || "Awaiting assignment")}</span>
        </div>
        <div class="key-value">
          <strong>Hospital</strong>
          <span>${escapeHtml(emergency.hospitalName || "Pending")}</span>
        </div>
        <div class="key-value">
          <strong>ETA</strong>
          <span>${escapeHtml(formatEta(emergency.etaMinutes || 0))}</span>
        </div>
        <div class="key-value">
          <strong>Traffic</strong>
          <span>${escapeHtml(capitalizeWords(emergency.trafficLevel || "moderate"))}</span>
        </div>
      </div>
      ${
        emergency.patientLocation
          ? `
            <div class="info-banner">
              <div class="icon-circle">P</div>
              <div>
                <strong>Pickup location</strong>
                <p>${escapeHtml(stringifyLocation(emergency.patientLocation))}</p>
              </div>
            </div>
          `
          : ""
      }
      ${options.footerHtml || ""}
    </div>
  `;
}

export function renderRequestCards(container, items = [], emptyMessage = "Nothing to show yet.") {
  if (!container) {
    return;
  }

  if (!items.length) {
    container.innerHTML = `
      <div class="empty-state">
        <h3>All clear</h3>
        <p>${escapeHtml(emptyMessage)}</p>
      </div>
    `;
    return;
  }

  container.innerHTML = items
    .map(
      (item) => `
        <article class="request-card">
          <div class="card-title-row">
            <div>
              <h4>${escapeHtml(item.title)}</h4>
              ${item.subtitle ? `<p class="muted-text">${escapeHtml(item.subtitle)}</p>` : ""}
            </div>
            ${item.badge ? `<span class="status-badge ${item.badgeTone || "tone-info"}">${escapeHtml(item.badge)}</span>` : ""}
          </div>
          ${item.body || ""}
        </article>
      `
    )
    .join("");
}

export function renderTableRows(container, rowsHtml) {
  if (!container) {
    return;
  }

  container.innerHTML = rowsHtml || `
    <tr>
      <td colspan="4">No records available.</td>
    </tr>
  `;
}

export function renderTimeline(container, steps = []) {
  if (!container) {
    return;
  }

  container.innerHTML = steps
    .map(
      (step) => `
        <div class="timeline-item">
          <span class="timeline-badge ${step.tone || "tone-info"}">${escapeHtml(step.badge)}</span>
          <div class="timeline-copy">
            <strong>${escapeHtml(step.title)}</strong>
            <p class="muted-text">${escapeHtml(step.description)}</p>
            ${step.time ? `<small>${escapeHtml(formatDateTime(step.time))}</small>` : ""}
          </div>
        </div>
      `
    )
    .join("");
}
