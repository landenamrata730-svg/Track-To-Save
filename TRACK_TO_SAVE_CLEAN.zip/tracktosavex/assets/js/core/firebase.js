import { firebaseConfig, useFirebase } from "../firebase-config.js";

const FIREBASE_VERSION = "12.10.0";

let firebaseCache = null;

export async function getFirebaseServices() {
  if (!useFirebase) {
    return null;
  }

  if (firebaseCache) {
    return firebaseCache;
  }

  const [appModule, authModule, firestoreModule, analyticsModule] = await Promise.all([
    import(`https://www.gstatic.com/firebasejs/${FIREBASE_VERSION}/firebase-app.js`),
    import(`https://www.gstatic.com/firebasejs/${FIREBASE_VERSION}/firebase-auth.js`),
    import(`https://www.gstatic.com/firebasejs/${FIREBASE_VERSION}/firebase-firestore.js`),
    import(`https://www.gstatic.com/firebasejs/${FIREBASE_VERSION}/firebase-analytics.js`),
  ]);

  const app = appModule.initializeApp(firebaseConfig);
  const auth = authModule.getAuth(app);
  const db = firestoreModule.getFirestore(app);
  await authModule.setPersistence(auth, authModule.browserLocalPersistence);

  let analytics = null;
  if (firebaseConfig.measurementId) {
    try {
      const analyticsSupported = await analyticsModule.isSupported();
      if (analyticsSupported) {
        analytics = analyticsModule.getAnalytics(app);
      }
    } catch (error) {
      analytics = null;
    }
  }

  firebaseCache = {
    app,
    auth,
    db,
    analytics,
    appModule,
    authModule,
    firestoreModule,
    analyticsModule,
  };

  return firebaseCache;
}

export async function getSecondaryAuthContext() {
  const services = await getFirebaseServices();
  if (!services) {
    return null;
  }

  const { appModule, authModule } = services;
  const appName = `track2save-admin-${Date.now()}`;
  const secondaryApp = appModule.initializeApp(firebaseConfig, appName);
  const secondaryAuth = authModule.getAuth(secondaryApp);

  await authModule.setPersistence(secondaryAuth, authModule.inMemoryPersistence);

  return {
    app: secondaryApp,
    auth: secondaryAuth,
    authModule,
    deleteApp: appModule.deleteApp,
  };
}
