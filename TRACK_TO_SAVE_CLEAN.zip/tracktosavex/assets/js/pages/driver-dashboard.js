import { playDispatchAlert, primeAlertAudio } from "../core/audio.js";
import { explainAppError } from "../core/errors.js";
import {
  clearDynamicLayers,
  createMap,
  fitToPoints,
  openGoogleMapsNavigation,
  upsertCircle,
  upsertMarker,
  upsertPolyline,
} from "../core/maps.js";
import {
  formatLocationAccuracy,
  getBestAvailableLocation,
  watchBrowserLocation,
} from "../core/location.js";
import {
  renderEmergencySummary,
  renderRequestCards,
  renderStatCards,
} from "../core/renderers.js";
import { bootstrapPage } from "../core/shell.js";
import {
  completeEmergency,
  subscribeEmergencies,
  subscribeUsers,
  updateDriverLocation,
  updateDriverStatus,
} from "../core/store.js";
import { capitalizeWords, formatDateTime, isActiveEmergency, stringifyLocation } from "../core/utils.js";
import { showToast } from "../core/ui.js";

document.addEventListener("DOMContentLoaded", async () => {
  const { user } = await bootstrapPage({
    currentPage: "driver-dashboard",
    requireAuth: true,
    allowedRoles: ["driver"],
  });
  if (!user) {
    return;
  }

  const statsTarget = document.getElementById("driver-stats");
  const assignmentTarget = document.getElementById("driver-active-assignment");
  const requestStream = document.getElementById("driver-request-stream");
  const routeTools = document.getElementById("driver-route-tools");
  const statusSelect = document.getElementById("driver-status-select");
  const map = createMap("driver-dashboard-map", { scrollWheelZoom: true });
  primeAlertAudio();

  let currentDriver = user;
  let users = [];
  let emergencies = [];
  let locationUpdateInFlight = false;
  let stopLocationWatch = () => {};
  let lastGpsFix = user.location
    ? {
        ...user.location,
        accuracy: Number(user.locationAccuracy || 0),
        source: user.locationSource || "saved profile",
      }
    : null;
  let gpsErrorMessage = "";
  let gpsMode = lastGpsFix ? "gps" : "pending";
  let lastPushTime = 0;
  let previousTripTrackingId = "";
  let hasTripSnapshot = false;

  const getDriverTrips = () =>
    emergencies.filter((emergency) => emergency.driverId === currentDriver.uid);

  const getActiveTrip = () => getDriverTrips().find((emergency) => isActiveEmergency(emergency));

  async function notifyNewAssignment() {
    const activeTrip = getActiveTrip();
    const currentTripId = activeTrip?.trackingId || "";

    if (!hasTripSnapshot) {
      previousTripTrackingId = currentTripId;
      hasTripSnapshot = true;
      return;
    }

    if (currentTripId && currentTripId !== previousTripTrackingId) {
      await playDispatchAlert();
      showToast(`New emergency assigned. Tracking ID ${currentTripId}.`, "error");
    }

    previousTripTrackingId = currentTripId;
  }

  const render = () => {
    const activeTrip = getActiveTrip();
    const completedTrips = getDriverTrips().filter((emergency) => emergency.status === "completed");
    statusSelect.value = currentDriver.status || "available";

    renderStatCards(statsTarget, [
      {
        label: "Driver status",
        value: capitalizeWords(currentDriver.status || "available"),
        badge: currentDriver.ambulanceNumber || "Ambulance",
        badgeTone:
          currentDriver.status === "available"
            ? "tone-success"
            : currentDriver.status === "offline"
              ? "tone-danger"
              : "tone-warning",
        helper: currentDriver.hospitalAffiliation || "Independent fleet",
      },
      {
        label: "Active assignment",
        value: activeTrip ? "1" : "0",
        helper: activeTrip ? "Smart dispatch is active" : "Waiting for nearest patient request",
      },
      {
        label: "GPS status",
        value:
          gpsMode === "gps"
            ? "Live"
            : "Waiting",
        helper:
          gpsMode === "gps"
            ? `Last GPS ping ${formatDateTime(currentDriver.lastLocationUpdate)}`
            : gpsErrorMessage || "Waiting for device permission",
      },
    ]);

    assignmentTarget.innerHTML = renderEmergencySummary(activeTrip, {
      title: activeTrip ? "Auto-assigned mission" : "No assignment yet",
      emptyMessage: "Stay available to receive the next nearby emergency.",
      footerHtml: activeTrip
        ? `
          <div class="info-banner">
            <div class="icon-circle">!</div>
            <div>
              <strong>Patient condition</strong>
              <p>${activeTrip.patientDetails?.condition || "Patient details will appear after form submission."}</p>
            </div>
          </div>
        `
        : "",
    });

    renderRequestCards(
      requestStream,
      getDriverTrips().map((trip) => ({
        title: `${trip.patientName || "Patient"} • ${trip.trackingId}`,
        subtitle: `Hospital: ${trip.hospitalName || "Pending"} • Updated ${formatDateTime(trip.updatedAt)}`,
        badge: trip.status,
        badgeTone:
          trip.status === "completed"
            ? "tone-success"
            : trip.status === "arrived"
              ? "tone-warning"
              : "tone-info",
        body: `
          <div class="key-value-grid">
            <div class="key-value">
              <strong>Ambulance</strong>
              <span>${currentDriver.ambulanceNumber || "Assigned fleet"}</span>
            </div>
            <div class="key-value">
              <strong>ETA</strong>
              <span>${trip.etaMinutes || 0} min</span>
            </div>
          </div>
          <div class="button-row app-note">
            <a class="btn btn-ghost btn-sm" href="live-tracking.html?trackingId=${trip.trackingId}">View Trip</a>
          </div>
        `,
      })),
      "Your incoming and completed patient trips will appear here."
    );

    routeTools.innerHTML = `
      <div class="info-banner">
        <div class="icon-circle">G</div>
        <div>
          <strong>Vehicle location</strong>
          <p>${currentDriver.location ? stringifyLocation(currentDriver.location) : "Location unavailable"}${lastGpsFix ? ` • ${formatLocationAccuracy(lastGpsFix)}` : ""}</p>
        </div>
      </div>
      <div class="key-value-grid">
        <div class="key-value">
          <strong>GPS mode</strong>
          <span>${gpsMode === "gps" ? "Live device GPS" : "Awaiting live GPS"}</span>
        </div>
        <div class="key-value">
          <strong>Last update</strong>
          <span>${formatDateTime(currentDriver.lastLocationUpdate)}</span>
        </div>
        ${
          activeTrip
            ? `
              <div class="key-value">
                <strong>Patient</strong>
                <span>${activeTrip.patientName || "Unknown"}</span>
              </div>
              <div class="key-value">
                <strong>Tracking ID</strong>
                <span>${activeTrip.trackingId}</span>
              </div>
            `
            : ""
        }
      </div>
      ${
        activeTrip
          ? `
            <div class="info-banner">
              <div class="icon-circle">T</div>
              <div>
                <strong>Traffic insight</strong>
                <p>${capitalizeWords(activeTrip.trafficLevel || "moderate")} traffic on the recommended route.</p>
              </div>
            </div>
          `
          : `
            <div class="empty-state">
              <h3>No active route</h3>
              <p>Keep your status available and the nearest emergency request will attach automatically.</p>
            </div>
          `
      }
      <div class="button-row">
        ${activeTrip ? `<button class="btn btn-primary" type="button" data-open-navigation>Open in Google Maps</button>` : ""}
        <button class="btn btn-secondary" type="button" data-refresh-location>Refresh GPS</button>
        ${activeTrip ? `<button class="btn btn-danger" type="button" data-complete-trip>Complete Trip</button>` : ""}
      </div>
    `;

    if (!map) {
      return;
    }

    clearDynamicLayers(map);
    if (!activeTrip) {
      if (currentDriver.location) {
        upsertMarker(map, "driver", currentDriver.location, {
          label: "A",
          color: "#0f6fff",
          popup: `${currentDriver.name} • ${capitalizeWords(currentDriver.status || "available")}`,
        });
        upsertCircle(map, "driver", currentDriver.location, {
          color: "#0f6fff",
          fillColor: "#0f6fff",
          radius: Number(currentDriver.locationAccuracy || lastGpsFix?.accuracy || 60),
          fillOpacity: 0.08,
        });
        fitToPoints(map, [currentDriver.location], { zoom: 16, maxZoom: 17 });
      }
      return;
    }

    upsertMarker(map, "driver", currentDriver.location, {
      label: "A",
      color: "#0f6fff",
      popup: `${currentDriver.name} • Ambulance`,
    });
    upsertCircle(map, "driver", currentDriver.location, {
      color: "#0f6fff",
      fillColor: "#0f6fff",
      radius: Number(currentDriver.locationAccuracy || lastGpsFix?.accuracy || 60),
      fillOpacity: 0.08,
    });
    upsertMarker(map, "patient", activeTrip.patientLocation, {
      label: "P",
      color: "#ef4444",
      popup: `${activeTrip.patientName || "Patient"} pickup`,
    });
    upsertCircle(map, "patient", activeTrip.patientLocation, {
      color: "#ef4444",
      fillColor: "#ef4444",
      radius: Number(activeTrip.patientLocationAccuracy || 80),
    });
    if (activeTrip.routePath?.length) {
      upsertPolyline(map, "route", activeTrip.routePath, {
        color:
          activeTrip.trafficLevel === "heavy"
            ? "#ef4444"
            : activeTrip.trafficLevel === "moderate"
              ? "#f59e0b"
              : "#16a34a",
      });
    }

    fitToPoints(map, [currentDriver.location, activeTrip.patientLocation].filter(Boolean));
  };

  async function pushDriverLocation(nextLocation) {
    if (locationUpdateInFlight || currentDriver.status === "offline" || !nextLocation) {
      return;
    }

    locationUpdateInFlight = true;
    try {
      currentDriver = {
        ...currentDriver,
        location: { lat: nextLocation.lat, lng: nextLocation.lng },
        locationAccuracy: Number(nextLocation.accuracy || 0),
        locationSource: nextLocation.source || "",
        lastLocationUpdate: nextLocation.capturedAt || new Date().toISOString(),
      };
      render();
      await updateDriverLocation(currentDriver.uid, nextLocation);
      lastPushTime = Date.now();
    } catch (error) {
      console.error(error);
    } finally {
      locationUpdateInFlight = false;
    }
  }

  stopLocationWatch = watchBrowserLocation({
    onUpdate: async (locationFix) => {
      lastGpsFix = locationFix;
      gpsMode = "gps";
      gpsErrorMessage = "";
      currentDriver = {
        ...currentDriver,
        location: { lat: locationFix.lat, lng: locationFix.lng },
        locationAccuracy: Number(locationFix.accuracy || 0),
        locationSource: locationFix.source || "gps",
        lastLocationUpdate: locationFix.capturedAt || new Date().toISOString(),
      };
      render();

      if (Date.now() - lastPushTime < 4750) {
        return;
      }

      await pushDriverLocation(locationFix);
    },
    onError: (error) => {
      gpsMode = "pending";
      gpsErrorMessage = explainAppError(error);
      render();
    },
  }, {
    timeout: 30000,
    maximumAge: 10000,
    transientErrorThreshold: 6,
  });

  window.addEventListener(
    "beforeunload",
    () => {
      stopLocationWatch();
    },
    { once: true }
  );

  document.getElementById("driver-status-save").addEventListener("click", async () => {
    try {
      await updateDriverStatus(currentDriver.uid, statusSelect.value);
      showToast("Driver status updated.", "success");
    } catch (error) {
      showToast(error.message || "Unable to update status.", "error");
    }
  });

  routeTools.addEventListener("click", async (event) => {
    const activeTrip = getActiveTrip();

    if (event.target.closest("[data-open-navigation]") && activeTrip) {
      openGoogleMapsNavigation(activeTrip.patientLocation, currentDriver.location);
    }

    if (event.target.closest("[data-refresh-location]")) {
      try {
        const locationFix = await getBestAvailableLocation({ warmupTimeoutMs: 28000 });
        lastGpsFix = locationFix;
        gpsMode = "gps";
        gpsErrorMessage = "";
        await pushDriverLocation(locationFix);
        showToast("Location refreshed from device GPS.", "success");
      } catch (error) {
        showToast(explainAppError(error), "error");
      }
    }

    if (event.target.closest("[data-complete-trip]") && activeTrip) {
      try {
        await completeEmergency(activeTrip.id);
        showToast("Trip marked as completed.", "success");
      } catch (error) {
        showToast(error.message || "Unable to complete the trip.", "error");
      }
    }
  });

  await subscribeUsers((nextUsers) => {
    users = nextUsers;
    currentDriver = users.find((candidate) => candidate.uid === user.uid) || currentDriver;
    render();
  });

  await subscribeEmergencies((nextEmergencies) => {
    emergencies = nextEmergencies;
    notifyNewAssignment();
    render();
  });
});
