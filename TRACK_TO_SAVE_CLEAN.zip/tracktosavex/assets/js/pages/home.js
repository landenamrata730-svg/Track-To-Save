import { bootstrapPage } from "../core/shell.js";

document.addEventListener("DOMContentLoaded", async () => {
  await bootstrapPage({ currentPage: "home" });
});
