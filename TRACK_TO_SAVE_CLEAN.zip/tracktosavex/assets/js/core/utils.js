import { DEFAULT_CENTER, TRAFFIC_LEVELS, ACTIVE_EMERGENCY_STATUSES } from "./config.js";

export function uid(prefix = "id") {
  if (typeof crypto !== "undefined" && crypto.randomUUID) {
    return `${prefix}-${crypto.randomUUID()}`;
  }

  return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}

export function deepClone(value) {
  return JSON.parse(JSON.stringify(value));
}

export function safeJsonParse(value, fallback) {
  try {
    return value ? JSON.parse(value) : fallback;
  } catch (error) {
    return fallback;
  }
}

export function nowIso() {
  return new Date().toISOString();
}

export function normalizeEmail(email = "") {
  return email.trim().toLowerCase();
}

export function parseNumber(value, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

export function parseLocationInput(value) {
  if (!value && value !== 0) {
    return null;
  }

  if (typeof value === "object" && value.lat !== undefined && value.lng !== undefined) {
    return {
      lat: parseNumber(value.lat),
      lng: parseNumber(value.lng),
    };
  }

  const [lat, lng] = String(value)
    .split(",")
    .map((item) => parseNumber(item.trim(), Number.NaN));

  if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
    return null;
  }

  return { lat, lng };
}

export function stringifyLocation(location) {
  if (!location || location.lat === undefined || location.lng === undefined) {
    return "Unavailable";
  }

  return `${Number(location.lat).toFixed(5)}, ${Number(location.lng).toFixed(5)}`;
}

export function capitalizeWords(text = "") {
  return String(text)
    .replace(/[_-]+/g, " ")
    .replace(/\b\w/g, (character) => character.toUpperCase());
}

export function formatDateTime(value) {
  if (!value) {
    return "Not updated";
  }

  return new Intl.DateTimeFormat("en-IN", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}

export function formatNumber(value = 0) {
  return new Intl.NumberFormat("en-IN").format(value);
}

export function formatEta(minutes = 0) {
  if (!minutes || minutes < 1) {
    return "Less than a minute";
  }

  if (minutes < 60) {
    return `${minutes} min`;
  }

  const hours = Math.floor(minutes / 60);
  const remainder = minutes % 60;
  return remainder ? `${hours}h ${remainder}m` : `${hours}h`;
}

export function escapeHtml(value = "") {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

export function haversineDistanceKm(start, end) {
  if (!start || !end) {
    return 0;
  }

  const earthRadiusKm = 6371;
  const latDelta = toRadians(end.lat - start.lat);
  const lngDelta = toRadians(end.lng - start.lng);
  const startLat = toRadians(start.lat);
  const endLat = toRadians(end.lat);

  const angle =
    Math.sin(latDelta / 2) * Math.sin(latDelta / 2) +
    Math.cos(startLat) * Math.cos(endLat) * Math.sin(lngDelta / 2) * Math.sin(lngDelta / 2);

  const arc = 2 * Math.atan2(Math.sqrt(angle), Math.sqrt(1 - angle));
  return earthRadiusKm * arc;
}

function toRadians(value) {
  return (value * Math.PI) / 180;
}

export function interpolatePoint(start, end, ratio = 0.5) {
  return {
    lat: start.lat + (end.lat - start.lat) * ratio,
    lng: start.lng + (end.lng - start.lng) * ratio,
  };
}

export function moveTowards(start, end, stepRatio = 0.18) {
  if (!start && !end) {
    return DEFAULT_CENTER;
  }

  if (!start) {
    return end;
  }

  if (!end) {
    return start;
  }

  const distance = haversineDistanceKm(start, end);
  if (distance <= 0.05) {
    return { ...end };
  }

  const ratio = Math.max(0.08, Math.min(stepRatio, 0.34));
  return interpolatePoint(start, end, ratio);
}

export function pickTrafficLevel(distanceKm = 0) {
  const seed = Math.abs(Math.round(distanceKm * 100)) % 9;

  if (seed <= 2) {
    return "low";
  }

  if (seed <= 5) {
    return "moderate";
  }

  return "heavy";
}

export function calculateEtaMinutes(distanceKm = 0, trafficLevel = "moderate") {
  const speedKmh = TRAFFIC_LEVELS[trafficLevel]?.speedKmh ?? TRAFFIC_LEVELS.moderate.speedKmh;
  return Math.max(2, Math.round((distanceKm / speedKmh) * 60));
}

export function buildSmartRoute(start, end) {
  if (!start || !end) {
    return {
      routePath: [],
      trafficLevel: "moderate",
      distanceKm: 0,
      etaMinutes: 0,
    };
  }

  const distanceKm = Number(haversineDistanceKm(start, end).toFixed(2));
  const trafficLevel = pickTrafficLevel(distanceKm);
  const bendRatio = trafficLevel === "heavy" ? 0.18 : trafficLevel === "moderate" ? 0.1 : 0.05;
  const midpoint = interpolatePoint(start, end, 0.5);
  const bend = {
    lat: midpoint.lat + (end.lng - start.lng) * bendRatio,
    lng: midpoint.lng + (start.lat - end.lat) * bendRatio,
  };

  return {
    routePath: [
      { ...start },
      interpolatePoint(start, bend, 0.5),
      bend,
      interpolatePoint(bend, end, 0.5),
      { ...end },
    ],
    trafficLevel,
    distanceKm,
    etaMinutes: calculateEtaMinutes(distanceKm, trafficLevel),
  };
}

export function isActiveEmergency(emergency) {
  return ACTIVE_EMERGENCY_STATUSES.includes(emergency?.status);
}

export function generateTrackingId(existingIds = []) {
  let nextId = "";

  do {
    nextId = `${Math.floor(10000 + Math.random() * 90000)}`;
  } while (existingIds.includes(nextId));

  return nextId;
}

export function getQueryParam(name) {
  const params = new URLSearchParams(window.location.search);
  return params.get(name);
}

export function sortByDateDesc(items = [], field = "updatedAt") {
  return [...items].sort((left, right) => {
    const leftValue = new Date(left?.[field] || 0).getTime();
    const rightValue = new Date(right?.[field] || 0).getTime();
    return rightValue - leftValue;
  });
}

export function getFullName(user) {
  return user?.name || user?.hospitalName || user?.displayName || "Unknown";
}

export function buildShareUrl(trackingId) {
  const url = new URL(window.location.href);
  url.pathname = `${url.pathname.replace(/[^/]+$/, "")}live-tracking.html`;
  url.searchParams.set("trackingId", trackingId);
  return url.toString();
}

export async function copyText(text) {
  if (!navigator.clipboard?.writeText) {
    return false;
  }

  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (error) {
    return false;
  }
}
