function extractFirebaseCode(error) {
  if (!error) {
    return "";
  }

  if (typeof error.code === "string" && error.code) {
    return error.code;
  }

  if (typeof error.message === "string") {
    const match = error.message.match(/\((auth\/[^)]+)\)/);
    if (match) {
      return match[1];
    }
  }

  const payloadCode = error?.customData?._tokenResponse?.error?.message;
  if (typeof payloadCode === "string") {
    return payloadCode;
  }

  return "";
}

export function explainAppError(error) {
  const code = extractFirebaseCode(error);
  const message = typeof error?.message === "string" ? error.message : "";

  if (code === "CONFIGURATION_NOT_FOUND" || code === "auth/configuration-not-found") {
    return "Authentication is not enabled for this project yet. Open Firebase Console > Authentication > Get started > Sign-in method, enable Email/Password, save, then try again.";
  }

  if (code === "auth/operation-not-allowed") {
    return "Email and password sign-in is disabled for this project. Enable Email/Password in the Authentication sign-in methods.";
  }

  if (code === "auth/invalid-credential" || code === "auth/wrong-password") {
    return "The email or password is incorrect.";
  }

  if (code === "auth/user-not-found") {
    return "No account was found for this email address.";
  }

  if (code === "auth/email-already-in-use") {
    return "An account with this email address already exists.";
  }

  if (code === "auth/weak-password") {
    return "Choose a stronger password with at least 6 characters.";
  }

  if (code === "auth/network-request-failed") {
    return "Network access failed while contacting the authentication service.";
  }

  if (message.includes("CONFIGURATION_NOT_FOUND")) {
    return "Authentication is not enabled for this project yet. Open Firebase Console > Authentication > Get started > Sign-in method, enable Email/Password, save, then try again.";
  }

  return message || "Something went wrong. Please try again.";
}
