let audioContext = null;
let primed = false;

function getAudioContext() {
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextClass) {
    return null;
  }

  if (!audioContext) {
    audioContext = new AudioContextClass();
  }

  return audioContext;
}

function unlockAudio() {
  const context = getAudioContext();
  if (!context) {
    return;
  }

  context.resume?.().catch(() => {});
}

export function primeAlertAudio() {
  if (primed || typeof window === "undefined") {
    return;
  }

  primed = true;

  const prime = () => {
    unlockAudio();
    document.removeEventListener("pointerdown", prime);
    document.removeEventListener("keydown", prime);
    document.removeEventListener("touchstart", prime);
  };

  document.addEventListener("pointerdown", prime, { passive: true });
  document.addEventListener("keydown", prime, { passive: true });
  document.addEventListener("touchstart", prime, { passive: true });
}

export async function playDispatchAlert() {
  const context = getAudioContext();
  if (!context) {
    return false;
  }

  try {
    await context.resume?.();
    const now = context.currentTime + 0.02;
    const compressor = context.createDynamicsCompressor();
    compressor.threshold.setValueAtTime(-20, now);
    compressor.knee.setValueAtTime(14, now);
    compressor.ratio.setValueAtTime(10, now);
    compressor.attack.setValueAtTime(0.003, now);
    compressor.release.setValueAtTime(0.22, now);
    compressor.connect(context.destination);

    [
      { type: "square", startFreq: 760, peakFreq: 1120, gain: 0.18 },
      { type: "triangle", startFreq: 380, peakFreq: 560, gain: 0.1 },
    ].forEach((voice) => {
      const oscillator = context.createOscillator();
      const gainNode = context.createGain();

      oscillator.type = voice.type;
      oscillator.connect(gainNode);
      gainNode.connect(compressor);

      gainNode.gain.setValueAtTime(0.0001, now);

      for (let index = 0; index < 4; index += 1) {
        const cycleStart = now + index * 0.42;
        oscillator.frequency.setValueAtTime(voice.startFreq, cycleStart);
        oscillator.frequency.linearRampToValueAtTime(voice.peakFreq, cycleStart + 0.15);
        oscillator.frequency.linearRampToValueAtTime(voice.startFreq, cycleStart + 0.34);
        gainNode.gain.exponentialRampToValueAtTime(voice.gain, cycleStart + 0.03);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, cycleStart + 0.4);
      }

      oscillator.start(now);
      oscillator.stop(now + 1.75);
    });

    return true;
  } catch (error) {
    return false;
  }
}
