import { DEFAULT_CENTER, MAP_TILE_ATTRIBUTION, MAP_TILE_URL } from "./config.js";
import { escapeHtml } from "./utils.js";

function ensureLeaflet() {
  return typeof window !== "undefined" && window.L;
}

function isFiniteCoordinate(value) {
  return Number.isFinite(Number(value));
}

function isValidLocation(location) {
  if (!location) {
    return false;
  }

  return isFiniteCoordinate(location.lat) && isFiniteCoordinate(location.lng);
}

function normalizePoint(location) {
  return [Number(location.lat), Number(location.lng)];
}

export function createMap(containerOrId, options = {}) {
  if (!ensureLeaflet()) {
    return null;
  }

  const container =
    typeof containerOrId === "string"
      ? document.getElementById(containerOrId)
      : containerOrId;

  if (!container) {
    return null;
  }

  if (container._leafletMap) {
    container._leafletMap.remove();
    container._leafletMap = null;
  }

  const center = options.center ?? DEFAULT_CENTER;
  const zoom = options.zoom ?? 13;
  const map = window.L.map(container, {
    scrollWheelZoom: options.scrollWheelZoom ?? false,
    zoomControl: options.zoomControl ?? true,
    preferCanvas: true,
  }).setView([center.lat, center.lng], zoom);

  window.L.tileLayer(MAP_TILE_URL, {
    maxZoom: 19,
    attribution: MAP_TILE_ATTRIBUTION,
  }).addTo(map);

  map.__layers = new Map();
  container._leafletMap = map;
  setTimeout(() => map.invalidateSize(), 120);
  setTimeout(() => map.invalidateSize(), 480);
  return map;
}

export function upsertMarker(map, key, location, options = {}) {
  if (!map || !isValidLocation(location) || !ensureLeaflet()) {
    return null;
  }

  const markerId = `marker:${key}`;
  const latLng = normalizePoint(location);
  const icon = window.L.divIcon({
    className: "custom-map-marker",
    html: `<span style="background:${options.color || "#0f6fff"}">${escapeHtml(
      options.label || ""
    )}</span>`,
    iconAnchor: [18, 18],
  });

  let marker = map.__layers.get(markerId);
  if (!marker) {
    marker = window.L.marker(latLng, { icon }).addTo(map);
    map.__layers.set(markerId, marker);
  } else {
    marker.setLatLng(latLng);
    marker.setIcon(icon);
  }

  if (options.popup) {
    marker.bindPopup(options.popup);
  }

  return marker;
}

export function upsertCircle(map, key, location, options = {}) {
  if (!map || !isValidLocation(location) || !ensureLeaflet()) {
    return null;
  }

  const layerId = `circle:${key}`;
  const latLng = normalizePoint(location);
  let circle = map.__layers.get(layerId);

  if (!circle) {
    circle = window.L.circle(latLng, {
      radius: options.radius ?? 280,
      color: options.color ?? "#ef4444",
      fillColor: options.fillColor ?? options.color ?? "#ef4444",
      fillOpacity: options.fillOpacity ?? 0.15,
      weight: options.weight ?? 2,
    }).addTo(map);
    map.__layers.set(layerId, circle);
  } else {
    circle.setLatLng(latLng);
    circle.setRadius(options.radius ?? 280);
    circle.setStyle({
      color: options.color ?? "#ef4444",
      fillColor: options.fillColor ?? options.color ?? "#ef4444",
    });
  }

  return circle;
}

export function upsertPolyline(map, key, points = [], options = {}) {
  const validPoints = points.filter(isValidLocation);
  if (!map || !validPoints.length || !ensureLeaflet()) {
    return null;
  }

  const layerId = `polyline:${key}`;
  const latLngs = validPoints.map(normalizePoint);
  let line = map.__layers.get(layerId);

  if (!line) {
    line = window.L.polyline(latLngs, {
      color: options.color ?? "#0f6fff",
      weight: options.weight ?? 5,
      opacity: options.opacity ?? 0.9,
      dashArray: options.dashArray,
    }).addTo(map);
    map.__layers.set(layerId, line);
  } else {
    line.setLatLngs(latLngs);
    line.setStyle({
      color: options.color ?? "#0f6fff",
      weight: options.weight ?? 5,
      opacity: options.opacity ?? 0.9,
      dashArray: options.dashArray,
    });
  }

  return line;
}

export function fitToPoints(map, points = [], options = {}) {
  if (!map || points.length === 0 || !ensureLeaflet()) {
    return;
  }

  const validPoints = points.filter(isValidLocation).map(normalizePoint);
  if (!validPoints.length) {
    return;
  }

  if (validPoints.length === 1) {
    map.setView(validPoints[0], options.zoom ?? 14);
    return;
  }

  map.fitBounds(validPoints, {
    padding: options.padding ?? [36, 36],
    maxZoom: options.maxZoom ?? 15,
  });
}

export function clearDynamicLayers(map) {
  if (!map?.__layers) {
    return;
  }

  map.__layers.forEach((layer) => {
    map.removeLayer(layer);
  });
  map.__layers.clear();
}

export function openGoogleMapsNavigation(destination, origin) {
  if (!destination) {
    return;
  }

  const url = new URL("https://www.google.com/maps/dir/");
  url.searchParams.set("api", "1");

  if (origin) {
    url.searchParams.set("origin", `${origin.lat},${origin.lng}`);
  }

  url.searchParams.set("destination", `${destination.lat},${destination.lng}`);
  window.open(url.toString(), "_blank", "noopener");
}

export function resetMapView(map) {
  if (!map) {
    return;
  }

  map.setView([DEFAULT_CENTER.lat, DEFAULT_CENTER.lng], 12);
}
