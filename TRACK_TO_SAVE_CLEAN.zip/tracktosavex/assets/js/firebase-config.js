export const appSettings = {
  appName: "Track2Save",
  driverLocationIntervalMs: 5000,
  defaultCenter: { lat: 17.6796, lng: 75.3302 },
};

export const firebaseConfig = {
  apiKey: "AIzaSyA4HWnM4fqEeeh4fanGH3Lf0mROtyfU9gs",
  authDomain: "track-to-save.firebaseapp.com",
  projectId: "track-to-save",
  storageBucket: "track-to-save.firebasestorage.app",
  messagingSenderId: "1001844160899",
  appId: "1:1001844160899:web:94c7294d8b8cecdd7f5eb6",
  measurementId: "G-0WZ8TFW9KN",
};

export function hasFirebaseCredentials() {
  return [
    firebaseConfig.apiKey,
    firebaseConfig.authDomain,
    firebaseConfig.projectId,
    firebaseConfig.storageBucket,
    firebaseConfig.messagingSenderId,
    firebaseConfig.appId,
  ].every(Boolean);
}

export const useFirebase = hasFirebaseCredentials();
