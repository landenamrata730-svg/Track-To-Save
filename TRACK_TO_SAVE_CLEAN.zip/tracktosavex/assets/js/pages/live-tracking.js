import { clearDynamicLayers, createMap, fitToPoints, upsertCircle, upsertMarker, upsertPolyline } from "../core/maps.js";
import { renderEmergencySummary, renderTimeline } from "../core/renderers.js";
import { bootstrapPage } from "../core/shell.js";
import { subscribeEmergencies, subscribeUsers } from "../core/store.js";
import { buildShareUrl, copyText, formatDateTime, getQueryParam, isActiveEmergency } from "../core/utils.js";
import { showToast } from "../core/ui.js";

document.addEventListener("DOMContentLoaded", async () => {
  const { user } = await bootstrapPage({ currentPage: "live-tracking" });
  const summaryTarget = document.getElementById("tracking-summary");
  const timelineTarget = document.getElementById("tracking-timeline");
  const sharePanel = document.getElementById("tracking-share-panel");
  const map = createMap("live-tracking-map");
  const trackingId = getQueryParam("trackingId");

  let users = [];
  let emergencies = [];

  function resolveEmergency() {
    if (trackingId) {
      return emergencies.find((emergency) => emergency.trackingId === trackingId) || null;
    }

    if (!user) {
      return null;
    }

    if (user.role === "patient") {
      return emergencies.find((emergency) => emergency.patientId === user.uid && isActiveEmergency(emergency)) || null;
    }

    if (user.role === "driver") {
      return emergencies.find((emergency) => emergency.driverId === user.uid && isActiveEmergency(emergency)) || null;
    }

    if (user.role === "hospital") {
      return emergencies.find((emergency) => emergency.hospitalId === user.uid && isActiveEmergency(emergency)) || null;
    }

    return emergencies.find((emergency) => isActiveEmergency(emergency)) || null;
  }

  function render() {
    const emergency = resolveEmergency();
    const driver = users.find((candidate) => candidate.uid === emergency?.driverId);
    const hospital = users.find((candidate) => candidate.uid === emergency?.hospitalId);
    const shareUrl = emergency ? buildShareUrl(emergency.trackingId) : "";

    summaryTarget.innerHTML = renderEmergencySummary(emergency, {
      title: emergency ? "Live emergency tracking" : "No emergency selected",
      emptyMessage:
        trackingId
          ? "This tracking ID could not be found yet."
          : "Open tracking with a 5-digit ID or sign in to view your active emergency.",
      footerHtml: emergency
        ? `
          <div class="info-banner">
            <div class="icon-circle">H</div>
            <div>
              <strong>Receiving hospital</strong>
              <p>${hospital?.name || emergency.hospitalName || "Pending hospital coordination"}</p>
            </div>
          </div>
        `
        : "",
    });

    if (!emergency) {
      timelineTarget.innerHTML = `
        <div class="empty-state">
          <h3>No live event</h3>
          <p>Use the tracking ID page or sign in to a role dashboard.</p>
        </div>
      `;
      sharePanel.innerHTML = `
        <div class="empty-state">
          <h3>Nothing to share</h3>
          <p>A tracking link becomes available after an emergency is dispatched.</p>
        </div>
      `;

      if (map) {
        clearDynamicLayers(map);
      }
      return;
    }

    renderTimeline(timelineTarget, [
      {
        badge: "Created",
        title: "Emergency request booked",
        description: "The patient request was confirmed and dispatch started.",
        time: emergency.createdAt,
        tone: "tone-danger",
      },
      {
        badge: "Dispatch",
        title: "Nearest driver auto-assigned",
        description: `${emergency.driverName || "Driver"} accepted automatically for the nearest route.`,
        time: emergency.updatedAt,
        tone: "tone-info",
      },
      {
        badge: "Hospital",
        title: emergency.bedPrepared ? "Bed prepared" : "Hospital notified",
        description: emergency.bedPrepared
          ? "Receiving hospital confirmed bed preparation."
          : "Hospital alert is active and waiting for readiness confirmation.",
        time: emergency.bedPreparedAt || emergency.updatedAt,
        tone: emergency.bedPrepared ? "tone-success" : "tone-warning",
      },
      {
        badge: "Status",
        title: `Current status: ${emergency.status}`,
        description:
          emergency.status === "completed"
            ? "Patient transfer has been completed."
            : "Live tracking is active until the ambulance arrives or the trip closes.",
        time: emergency.completedAt || emergency.updatedAt,
        tone: emergency.status === "completed" ? "tone-success" : "tone-info",
      },
    ]);

    sharePanel.innerHTML = `
      <div class="tracking-id-box">
        <span>Emergency Tracking ID</span>
        <strong>${emergency.trackingId}</strong>
      </div>
      <div class="key-value-grid">
        <div class="key-value">
          <strong>Driver phone</strong>
          <span>${driver?.phone || emergency.driverPhone || "Unavailable"}</span>
        </div>
        <div class="key-value">
          <strong>Last updated</strong>
          <span>${formatDateTime(emergency.updatedAt)}</span>
        </div>
      </div>
      <div class="button-row">
        <button class="btn btn-primary" type="button" data-copy-tracking-link="${shareUrl}">Copy Share Link</button>
        <a class="btn btn-secondary" href="tracking-id.html">Open Tracking ID Page</a>
      </div>
    `;

    if (!map) {
      return;
    }

    clearDynamicLayers(map);

    if (emergency.patientLocation) {
      upsertMarker(map, "patient", emergency.patientLocation, {
        label: "P",
        color: "#ef4444",
        popup: emergency.patientName || "Patient",
      });
      upsertCircle(map, "patient", emergency.patientLocation, {
        color: "#ef4444",
        fillColor: "#ef4444",
        radius: Number(emergency.patientLocationAccuracy || 80),
      });
    }

    if (driver?.location) {
      upsertMarker(map, "driver", driver.location, {
        label: "A",
        color: "#0f6fff",
        popup: driver.name,
      });
      upsertCircle(map, "driver", driver.location, {
        color: "#0f6fff",
        fillColor: "#0f6fff",
        radius: Number(driver.locationAccuracy || 60),
        fillOpacity: 0.08,
      });
    }

    if (hospital?.location) {
      upsertMarker(map, "hospital", hospital.location, {
        label: "H",
        color: "#16a34a",
        popup: hospital.name,
      });
    }

    if (emergency.routePath?.length) {
      upsertPolyline(map, "route", emergency.routePath, {
        color:
          emergency.trafficLevel === "heavy"
            ? "#ef4444"
            : emergency.trafficLevel === "moderate"
              ? "#f59e0b"
              : "#16a34a",
      });
    }

    fitToPoints(map, [emergency.patientLocation, driver?.location, hospital?.location].filter(Boolean));
  }

  sharePanel.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-copy-tracking-link]");
    if (!button) {
      return;
    }

    const copied = await copyText(button.dataset.copyTrackingLink);
    showToast(copied ? "Tracking link copied." : "Clipboard is unavailable.", copied ? "success" : "error");
  });

  await subscribeUsers((nextUsers) => {
    users = nextUsers;
    render();
  });

  await subscribeEmergencies((nextEmergencies) => {
    emergencies = nextEmergencies;
    render();
  });
});
