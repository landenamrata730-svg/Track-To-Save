import { clearDynamicLayers, createMap, fitToPoints, upsertCircle, upsertMarker, upsertPolyline } from "../core/maps.js";
import { renderEmergencySummary, renderRequestCards, renderStatCards } from "../core/renderers.js";
import { bootstrapPage } from "../core/shell.js";
import { subscribeEmergencies, subscribeUsers } from "../core/store.js";
import { formatDateTime, isActiveEmergency } from "../core/utils.js";

document.addEventListener("DOMContentLoaded", async () => {
  const { user } = await bootstrapPage({
    currentPage: "patient-dashboard",
    requireAuth: true,
    allowedRoles: ["patient"],
  });
  if (!user) {
    return;
  }

  const statsTarget = document.getElementById("patient-stats");
  const activeTarget = document.getElementById("patient-active-emergency");
  const historyTarget = document.getElementById("patient-trip-history");
  const map = createMap("patient-dashboard-map");

  let users = [];
  let emergencies = [];

  const render = () => {
    const patientEmergencies = emergencies.filter((emergency) => emergency.patientId === user.uid);
    const activeEmergency = patientEmergencies.find((emergency) => isActiveEmergency(emergency));
    const driver = users.find((candidate) => candidate.uid === activeEmergency?.driverId);
    const completedTrips = patientEmergencies.filter((emergency) => emergency.status === "completed");

    renderStatCards(statsTarget, [
      {
        label: "Active emergency",
        value: activeEmergency ? "Yes" : "No",
        badge: activeEmergency?.trackingId || "Standby",
        badgeTone: activeEmergency ? "tone-danger" : "tone-success",
        helper: activeEmergency ? "Dispatch already in progress" : "Ready to book",
      },
      {
        label: "Completed trips",
        value: completedTrips.length,
        helper: "Historical ambulance transfers",
      },
      {
        label: "Live ETA",
        value: activeEmergency ? `${activeEmergency.etaMinutes || 0} min` : "--",
        helper: "Traffic-aware simulated estimate",
      },
    ]);

    activeTarget.innerHTML = renderEmergencySummary(activeEmergency, {
      title: activeEmergency ? "Ambulance dispatched" : "No ambulance in transit",
      emptyMessage: "Book an ambulance when you need emergency support.",
      footerHtml: activeEmergency
        ? `
          <div class="button-row">
            <a class="btn btn-primary btn-sm" href="live-tracking.html?trackingId=${activeEmergency.trackingId}">Open Live Tracking</a>
            <a class="btn btn-secondary btn-sm" href="tracking-id.html">Share Tracking ID</a>
          </div>
          ${
            driver
              ? `
                <div class="info-banner">
                  <div class="icon-circle">D</div>
                  <div>
                    <strong>${driver.name}</strong>
                    <p>${driver.ambulanceNumber || "Ambulance"} is moving toward your location.</p>
                  </div>
                </div>
              `
              : ""
          }
        `
        : `<div class="button-row"><a class="btn btn-primary" href="book-ambulance.html">Book Ambulance</a></div>`,
    });

    renderRequestCards(
      historyTarget,
      patientEmergencies.map((emergency) => ({
        title: `${emergency.hospitalName || "Emergency request"} • ${emergency.trackingId}`,
        subtitle: `Updated ${formatDateTime(emergency.updatedAt)}`,
        badge: emergency.status,
        badgeTone:
          emergency.status === "completed"
            ? "tone-success"
            : emergency.status === "arrived"
              ? "tone-warning"
              : "tone-info",
        body: `
          <div class="key-value-grid">
            <div class="key-value">
              <strong>Driver</strong>
              <span>${emergency.driverName || "Pending"}</span>
            </div>
            <div class="key-value">
              <strong>ETA</strong>
              <span>${emergency.etaMinutes || 0} min</span>
            </div>
          </div>
          <div class="button-row app-note">
            <a class="btn btn-ghost btn-sm" href="live-tracking.html?trackingId=${emergency.trackingId}">View Tracking</a>
          </div>
        `,
      })),
      "Your recent emergencies will appear here."
    );

    if (!map) {
      return;
    }

    clearDynamicLayers(map);
    if (!activeEmergency) {
      return;
    }

    upsertMarker(map, "patient", activeEmergency.patientLocation, {
      label: "P",
      color: "#ef4444",
      popup: "Patient pickup point",
    });
    upsertCircle(map, "patient", activeEmergency.patientLocation, {
      color: "#ef4444",
      fillColor: "#ef4444",
      radius: Number(activeEmergency.patientLocationAccuracy || 80),
    });

    if (driver?.location) {
      upsertMarker(map, "driver", driver.location, {
        label: "A",
        color: "#0f6fff",
        popup: `${driver.name} • ${driver.ambulanceNumber || "Ambulance"}`,
      });
      upsertCircle(map, "driver", driver.location, {
        color: "#0f6fff",
        fillColor: "#0f6fff",
        radius: Number(driver.locationAccuracy || 60),
        fillOpacity: 0.08,
      });
    }

    if (activeEmergency.routePath?.length) {
      upsertPolyline(map, "route", activeEmergency.routePath, {
        color: activeEmergency.trafficLevel === "heavy" ? "#ef4444" : activeEmergency.trafficLevel === "moderate" ? "#f59e0b" : "#16a34a",
      });
    }

    fitToPoints(map, [activeEmergency.patientLocation, driver?.location].filter(Boolean));
  };

  await subscribeUsers((nextUsers) => {
    users = nextUsers;
    render();
  });

  await subscribeEmergencies((nextEmergencies) => {
    emergencies = nextEmergencies;
    render();
  });
});
