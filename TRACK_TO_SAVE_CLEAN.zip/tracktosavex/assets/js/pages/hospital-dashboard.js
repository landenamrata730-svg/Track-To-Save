import { playDispatchAlert, primeAlertAudio } from "../core/audio.js";
import { clearDynamicLayers, createMap, fitToPoints, upsertMarker, upsertPolyline } from "../core/maps.js";
import { renderRequestCards, renderStatCards } from "../core/renderers.js";
import { bootstrapPage } from "../core/shell.js";
import { prepareHospitalBed, subscribeEmergencies, subscribeUsers } from "../core/store.js";
import { capitalizeWords, formatDateTime, isActiveEmergency } from "../core/utils.js";
import { showToast } from "../core/ui.js";

document.addEventListener("DOMContentLoaded", async () => {
  const { user } = await bootstrapPage({
    currentPage: "hospital-dashboard",
    requireAuth: true,
    allowedRoles: ["hospital"],
  });
  if (!user) {
    return;
  }

  const statsTarget = document.getElementById("hospital-stats");
  const alertsTarget = document.getElementById("hospital-alerts");
  const arrivalsTarget = document.getElementById("hospital-arrivals");
  const map = createMap("hospital-dashboard-map");
  primeAlertAudio();

  let currentHospital = user;
  let users = [];
  let emergencies = [];
  let knownIncomingIds = new Set();
  let hasIncomingSnapshot = false;

  const hospitalEmergencies = () =>
    emergencies.filter((emergency) => emergency.hospitalId === currentHospital.uid);

  async function notifyIncomingAlert() {
    const incomingIds = hospitalEmergencies()
      .filter((emergency) => isActiveEmergency(emergency))
      .map((emergency) => emergency.id);

    if (!hasIncomingSnapshot) {
      knownIncomingIds = new Set(incomingIds);
      hasIncomingSnapshot = true;
      return;
    }

    const nextIncoming = incomingIds.find((id) => !knownIncomingIds.has(id));
    knownIncomingIds = new Set(incomingIds);

    if (nextIncoming) {
      await playDispatchAlert();
      showToast("New ambulance alert received for your hospital.", "error");
    }
  }

  const render = () => {
    const incoming = hospitalEmergencies().filter((emergency) => isActiveEmergency(emergency));
    const completed = hospitalEmergencies().filter((emergency) => emergency.status === "completed");

    renderStatCards(statsTarget, [
      {
        label: "Incoming ambulances",
        value: incoming.length,
        badge: `${currentHospital.availableBeds || 0} beds`,
        badgeTone: Number(currentHospital.availableBeds || 0) > 2 ? "tone-success" : "tone-warning",
        helper: "Live incoming requests to your hospital",
      },
      {
        label: "ICU beds",
        value: currentHospital.icuBeds || 0,
        helper: "Configured hospital ICU capacity",
      },
      {
        label: "Completed arrivals",
        value: completed.length,
        helper: "Emergency transfers completed",
      },
    ]);

    renderRequestCards(
      alertsTarget,
      incoming.map((emergency) => ({
        title: `${emergency.patientName || "Patient"} • ${emergency.trackingId}`,
        subtitle: `Driver ${emergency.driverName || "Assigned"} • ETA ${emergency.etaMinutes || 0} min`,
        badge: emergency.bedPrepared ? "Bed Prepared" : emergency.status,
        badgeTone: emergency.bedPrepared ? "tone-success" : "tone-warning",
        body: `
          <div class="key-value-grid">
            <div class="key-value">
              <strong>Condition</strong>
              <span>${emergency.patientDetails?.condition || "Awaiting patient details"}</span>
            </div>
            <div class="key-value">
              <strong>Traffic</strong>
              <span>${capitalizeWords(emergency.trafficLevel || "moderate")}</span>
            </div>
          </div>
          <div class="button-row app-note">
            ${
              emergency.bedPrepared
                ? `<span class="status-badge tone-success">Bed ready</span>`
                : `<button class="btn btn-primary btn-sm" type="button" data-prepare-bed="${emergency.id}">Prepare Bed</button>`
            }
            <a class="btn btn-ghost btn-sm" href="live-tracking.html?trackingId=${emergency.trackingId}">Open Tracking</a>
          </div>
        `,
      })),
      "Incoming emergency alerts will appear here as soon as an ambulance is routed to your hospital."
    );

    renderRequestCards(
      arrivalsTarget,
      hospitalEmergencies().map((emergency) => ({
        title: `${emergency.patientName || "Patient"} → ${currentHospital.name}`,
        subtitle: `Last update ${formatDateTime(emergency.updatedAt)}`,
        badge: emergency.status,
        badgeTone:
          emergency.status === "completed"
            ? "tone-success"
            : emergency.status === "arrived"
              ? "tone-warning"
              : "tone-info",
        body: `
          <div class="key-value-grid">
            <div class="key-value">
              <strong>Driver</strong>
              <span>${emergency.driverName || "Assigned"}</span>
            </div>
            <div class="key-value">
              <strong>Tracking ID</strong>
              <span>${emergency.trackingId}</span>
            </div>
          </div>
        `,
      })),
      "Active and historical arrivals will be listed here."
    );

    if (!map) {
      return;
    }

    clearDynamicLayers(map);
    const points = [];

    if (currentHospital.location) {
      upsertMarker(map, "hospital", currentHospital.location, {
        label: "H",
        color: "#0f6fff",
        popup: currentHospital.name,
      });
      points.push(currentHospital.location);
    }

    incoming.forEach((emergency) => {
      const driver = users.find((candidate) => candidate.uid === emergency.driverId);
      if (emergency.patientLocation) {
        upsertMarker(map, `patient-${emergency.id}`, emergency.patientLocation, {
          label: "P",
          color: "#ef4444",
          popup: emergency.patientName || "Patient",
        });
        points.push(emergency.patientLocation);
      }

      if (driver?.location) {
        upsertMarker(map, `driver-${emergency.id}`, driver.location, {
          label: "A",
          color: "#f59e0b",
          popup: driver.name,
        });
        points.push(driver.location);
      }

      if (emergency.routePath?.length) {
        upsertPolyline(map, `route-${emergency.id}`, emergency.routePath, {
          color:
            emergency.trafficLevel === "heavy"
              ? "#ef4444"
              : emergency.trafficLevel === "moderate"
                ? "#f59e0b"
                : "#16a34a",
        });
      }
    });

    if (points.length) {
      fitToPoints(map, points);
    }
  };

  alertsTarget.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-prepare-bed]");
    if (!button) {
      return;
    }

    try {
      await prepareHospitalBed(button.dataset.prepareBed, currentHospital.uid);
      showToast("Bed preparation confirmed.", "success");
    } catch (error) {
      showToast(error.message || "Unable to prepare the bed.", "error");
    }
  });

  await subscribeUsers((nextUsers) => {
    users = nextUsers;
    currentHospital = users.find((candidate) => candidate.uid === user.uid) || currentHospital;
    render();
  });

  await subscribeEmergencies((nextEmergencies) => {
    emergencies = nextEmergencies;
    notifyIncomingAlert();
    render();
  });
});
