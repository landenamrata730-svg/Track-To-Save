import { explainAppError } from "../core/errors.js";
import {
  geocodeCityName,
  reverseGeocodeLocation,
  stringifyCoordinateStorage,
} from "../core/geocoding.js";
import { getBestAvailableLocation } from "../core/location.js";
import { getDashboardPath, bootstrapPage } from "../core/shell.js";
import { updateUser } from "../core/store.js";
import { parseLocationInput } from "../core/utils.js";
import { showToast } from "../core/ui.js";

document.addEventListener("DOMContentLoaded", async () => {
  const { user } = await bootstrapPage({ currentPage: "profile", requireAuth: true });
  if (!user) {
    return;
  }

  const form = document.getElementById("profile-form");
  const patientFields = document.getElementById("profile-patient-fields");
  const driverFields = document.getElementById("profile-driver-fields");
  const hospitalFields = document.getElementById("profile-hospital-fields");
  const findCityButton = document.getElementById("profile-find-city");
  const gpsButton = document.getElementById("profile-use-gps");
  const locationField = document.getElementById("profile-location");
  const locationLabelField = document.getElementById("profile-location-label");
  let capturedLocationFix = user.location
    ? {
        ...user.location,
        accuracy: Number(user.locationAccuracy || 0),
        source: user.locationSource || "saved profile",
      }
    : null;

  function showRoleFields(role) {
    patientFields.classList.toggle("hidden", role !== "patient");
    driverFields.classList.toggle("hidden", role !== "driver");
    hospitalFields.classList.toggle("hidden", role !== "hospital");
  }

  function setValue(id, value) {
    const field = document.getElementById(id);
    if (field) {
      field.value = value ?? "";
    }
  }

  showRoleFields(user.role);
  setValue("profile-name", user.name);
  setValue("profile-phone", user.phone);
  setValue("profile-email", user.email);
  setValue("profile-location", user.location ? stringifyCoordinateStorage(user.location) : "");
  setValue("profile-location-label", user.locationLabel || (user.location ? "Saved map point" : ""));

  if (user.role === "patient") {
    setValue("profile-age", user.age);
    setValue("profile-blood-group", user.bloodGroup);
    setValue("profile-emergency-contact", user.emergencyContact);
    setValue("profile-allergies", user.allergies);
  }

  if (user.role === "driver") {
    setValue("profile-ambulance-number", user.ambulanceNumber);
    setValue("profile-license-number", user.licenseNumber);
    setValue("profile-driver-status", user.status || "available");
    setValue("profile-hospital-affiliation", user.hospitalAffiliation);
  }

  if (user.role === "hospital") {
    setValue("profile-address", user.address);
    setValue("profile-hospital-contact", user.emergencyContactNumber);
    setValue("profile-ambulance-count", user.ambulanceCount);
    setValue("profile-available-beds", user.availableBeds);
    setValue("profile-icu-beds", user.icuBeds);
  }

  locationLabelField.addEventListener("input", () => {
    locationField.value = "";
  });

  async function resolveProfileLocation() {
    const label = locationLabelField.value.trim();
    const rawCoords = locationField.value.trim();
    if (!label || rawCoords) {
      return;
    }

    const result = await geocodeCityName(label);
    locationLabelField.value = result.label || label;
    locationField.value = result.currentLocation;
  }

  findCityButton.addEventListener("click", async () => {
    try {
      await resolveProfileLocation();
      showToast("City located on the map successfully.", "success");
    } catch (error) {
      showToast(explainAppError(error), "error");
    }
  });

  gpsButton.addEventListener("click", async () => {
    try {
      capturedLocationFix = await getBestAvailableLocation({ warmupTimeoutMs: 28000 });
      const reverse = await reverseGeocodeLocation(capturedLocationFix);
      locationLabelField.value = reverse?.label || "Current GPS location";
      locationField.value = stringifyCoordinateStorage(capturedLocationFix);
      showToast("Profile location captured from GPS.", "success");
    } catch (error) {
      showToast(explainAppError(error), "error");
    }
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    try {
      const patch = {
        name: document.getElementById("profile-name").value.trim(),
        phone: document.getElementById("profile-phone").value.trim(),
        locationLabel: locationLabelField.value.trim(),
      };

      await resolveProfileLocation();
      const location = parseLocationInput(locationField.value);
      if (location) {
        patch.location = location;
        if (capturedLocationFix) {
          patch.locationAccuracy = Number(capturedLocationFix.accuracy || 0);
          patch.locationSource = capturedLocationFix.source || "gps";
        }
      }

      if (user.role === "patient") {
        Object.assign(patch, {
          age: document.getElementById("profile-age").value.trim(),
          bloodGroup: document.getElementById("profile-blood-group").value.trim(),
          emergencyContact: document.getElementById("profile-emergency-contact").value.trim(),
          allergies: document.getElementById("profile-allergies").value.trim(),
        });
      }

      if (user.role === "driver") {
        Object.assign(patch, {
          ambulanceNumber: document.getElementById("profile-ambulance-number").value.trim(),
          licenseNumber: document.getElementById("profile-license-number").value.trim(),
          status: document.getElementById("profile-driver-status").value,
          hospitalAffiliation: document.getElementById("profile-hospital-affiliation").value.trim(),
        });
      }

      if (user.role === "hospital") {
        Object.assign(patch, {
          address: document.getElementById("profile-address").value.trim(),
          emergencyContactNumber: document.getElementById("profile-hospital-contact").value.trim(),
          ambulanceCount: Number(document.getElementById("profile-ambulance-count").value || 0),
          availableBeds: Number(document.getElementById("profile-available-beds").value || 0),
          icuBeds: Number(document.getElementById("profile-icu-beds").value || 0),
        });
      }

      await updateUser(user.uid, patch);
      showToast("Profile updated successfully.", "success");
      window.location.href = getDashboardPath(user.role);
    } catch (error) {
      showToast(explainAppError(error), "error");
    }
  });
});
