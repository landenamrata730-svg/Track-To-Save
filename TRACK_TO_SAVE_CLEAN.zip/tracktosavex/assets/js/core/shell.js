import { DASHBOARD_PATHS } from "./config.js";
import { logout, onAuthChange, waitForAuth } from "./store.js";
import { renderShell, showToast } from "./ui.js";

const SHELL_USER_CACHE_KEY = "track2save:shell-user";

export function getDashboardPath(role) {
  return DASHBOARD_PATHS[role] || "index.html";
}

export function redirectToLogin() {
  const next = encodeURIComponent(window.location.pathname.split("/").pop() || "index.html");
  window.location.href = `login.html?next=${next}`;
}

export function redirectToDashboard(user) {
  window.location.href = getDashboardPath(user?.role);
}

export function consumeNextRoute() {
  const params = new URLSearchParams(window.location.search);
  return params.get("next");
}

function readCachedShellUser() {
  try {
    const cached = sessionStorage.getItem(SHELL_USER_CACHE_KEY);
    return cached ? JSON.parse(cached) : null;
  } catch (error) {
    return null;
  }
}

function writeCachedShellUser(user) {
  try {
    if (user) {
      sessionStorage.setItem(SHELL_USER_CACHE_KEY, JSON.stringify(user));
    } else {
      sessionStorage.removeItem(SHELL_USER_CACHE_KEY);
    }
  } catch (error) {
    // Ignore storage unavailability and keep the shell functional.
  }
}

export async function bootstrapPage({ currentPage, requireAuth = false, allowedRoles = [] }) {
  renderShell({ currentPage, user: readCachedShellUser() });

  const user = await waitForAuth();
  writeCachedShellUser(user);
  renderShell({ currentPage, user });

  const unsubscribe = onAuthChange((nextUser) => {
    writeCachedShellUser(nextUser);
    renderShell({ currentPage, user: nextUser });
  });

  window.addEventListener(
    "beforeunload",
    () => {
      unsubscribe();
    },
    { once: true }
  );

  document.addEventListener("click", async (event) => {
    const logoutButton = event.target.closest("[data-logout-button]");
    if (!logoutButton) {
      return;
    }

    await logout();
    showToast("You have been signed out.", "success");
    window.location.href = "index.html";
  });

  if (requireAuth && !user) {
    redirectToLogin();
    return { user: null };
  }

  if (allowedRoles.length && user && !allowedRoles.includes(user.role)) {
    redirectToDashboard(user);
    return { user };
  }

  return { user };
}
