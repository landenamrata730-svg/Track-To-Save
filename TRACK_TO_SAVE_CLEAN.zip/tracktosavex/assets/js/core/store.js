import { useFirebase } from "../firebase-config.js";
import { ACTIVE_EMERGENCY_STATUSES, DEFAULT_CENTER } from "./config.js";
import { getFirebaseServices, getSecondaryAuthContext } from "./firebase.js";
import { getSmartRoute } from "./routing.js";
import {
  deepClone,
  generateTrackingId,
  getFullName,
  haversineDistanceKm,
  isActiveEmergency,
  normalizeEmail,
  nowIso,
  parseLocationInput,
  safeJsonParse,
  sortByDateDesc,
  uid,
} from "./utils.js";

const STORAGE_KEY = "track2save:demo-db";
const SESSION_KEY = "track2save:demo-session";
const DATA_EVENT = "track2save:data-changed";

let initialized = false;
let initializingPromise = null;
let firebaseServices = null;
let currentUser = null;
let authReadyPromise = null;
let authResolved = false;
const authListeners = new Set();

function seedDemoDatabase() {
  const seededAt = nowIso();

  const users = [
    {
      uid: "admin-demo-1",
      role: "admin",
      name: "Track2Save Command Center",
      email: "admin@track2save.demo",
      password: "Admin@123",
      phone: "+91 90000 00001",
      location: DEFAULT_CENTER,
      createdAt: seededAt,
      updatedAt: seededAt,
    },
    {
      uid: "patient-demo-1",
      role: "patient",
      name: "Ananya Patel",
      email: "patient@track2save.demo",
      password: "Patient@123",
      phone: "+91 98765 43210",
      age: "29",
      bloodGroup: "B+",
      allergies: "Penicillin",
      emergencyContact: "+91 99887 76655",
      createdAt: seededAt,
      updatedAt: seededAt,
    },
    {
      uid: "driver-demo-1",
      role: "driver",
      name: "Rohit Nair",
      email: "driver@track2save.demo",
      password: "Driver@123",
      phone: "+91 98111 22334",
      ambulanceNumber: "MH 01 AB 2044",
      licenseNumber: "DL-AMB-8841",
      location: { lat: 17.6818, lng: 75.3226 },
      hospitalId: "hospital-demo-1",
      hospitalAffiliation: "Pandharpur Lifeline Hospital",
      status: "available",
      lastLocationUpdate: seededAt,
      createdAt: seededAt,
      updatedAt: seededAt,
    },
    {
      uid: "driver-demo-2",
      role: "driver",
      name: "Maya Fernandes",
      email: "maya.driver@track2save.demo",
      password: "Driver@123",
      phone: "+91 98222 33445",
      ambulanceNumber: "MH 02 CD 1180",
      licenseNumber: "DL-AMB-7713",
      location: { lat: 17.6694, lng: 75.3361 },
      hospitalId: "hospital-demo-2",
      hospitalAffiliation: "Vitthal Emergency Center",
      status: "available",
      lastLocationUpdate: seededAt,
      createdAt: seededAt,
      updatedAt: seededAt,
    },
    {
      uid: "hospital-demo-1",
      role: "hospital",
      name: "Pandharpur Lifeline Hospital",
      email: "hospital@track2save.demo",
      password: "Hospital@123",
      phone: "+91 99880 40001",
      address: "Station Road, Pandharpur",
      emergencyContactNumber: "+91 99880 40001",
      ambulanceCount: 6,
      availableBeds: 12,
      icuBeds: 4,
      location: { lat: 17.6775, lng: 75.3268 },
      createdAt: seededAt,
      updatedAt: seededAt,
    },
    {
      uid: "hospital-demo-2",
      role: "hospital",
      name: "Vitthal Emergency Center",
      email: "metro.hospital@track2save.demo",
      password: "Hospital@123",
      phone: "+91 99880 40002",
      address: "College Road, Pandharpur",
      emergencyContactNumber: "+91 99880 40002",
      ambulanceCount: 8,
      availableBeds: 9,
      icuBeds: 3,
      location: { lat: 17.6668, lng: 75.3342 },
      createdAt: seededAt,
      updatedAt: seededAt,
    },
  ];

  const previousRoute = {
    routePath: [
      { lat: 17.6818, lng: 75.3226 },
      { lat: 17.6794, lng: 75.3251 },
      { lat: 17.6761, lng: 75.3279 },
    ],
    trafficLevel: "moderate",
    distanceKm: 0.82,
    etaMinutes: 4,
  };

  const emergencies = [
    {
      id: "emergency-demo-completed",
      trackingId: "41207",
      patientId: "patient-demo-1",
      patientName: "Ananya Patel",
      patientPhone: "+91 98765 43210",
      patientLocation: { lat: 17.6761, lng: 75.3279 },
      driverId: "driver-demo-1",
      driverName: "Rohit Nair",
      driverPhone: "+91 98111 22334",
      ambulanceNumber: "MH 01 AB 2044",
      hospitalId: "hospital-demo-1",
      hospitalName: "Pandharpur Lifeline Hospital",
      status: "completed",
      patientDetails: {
        age: "29",
        bloodGroup: "B+",
        condition: "Chest pain",
        notes: "Stable during transfer",
      },
      routePath: previousRoute.routePath,
      trafficLevel: previousRoute.trafficLevel,
      distanceKm: previousRoute.distanceKm,
      etaMinutes: previousRoute.etaMinutes,
      bedPrepared: true,
      autoAssigned: true,
      createdAt: new Date(Date.now() - 1000 * 60 * 240).toISOString(),
      updatedAt: new Date(Date.now() - 1000 * 60 * 200).toISOString(),
      completedAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
    },
  ];

  return {
    version: 1,
    createdAt: seededAt,
    users,
    emergencies,
  };
}

function sanitizeUser(user) {
  if (!user) {
    return null;
  }

  const clone = deepClone(user);
  delete clone.password;
  return clone;
}

function emitAuthChange(user) {
  currentUser = user ? sanitizeUser(user) : null;
  authListeners.forEach((listener) => listener(currentUser));
}

function ensureDemoDatabase() {
  const existing = safeJsonParse(localStorage.getItem(STORAGE_KEY), null);
  if (existing?.users && existing?.emergencies) {
    return existing;
  }

  const seeded = seedDemoDatabase();
  localStorage.setItem(STORAGE_KEY, JSON.stringify(seeded));
  return seeded;
}

function loadDemoDatabase() {
  return ensureDemoDatabase();
}

function saveDemoDatabase(database) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(database));
  window.dispatchEvent(new Event(DATA_EVENT));
}

function mutateDemoDatabase(mutator) {
  const database = loadDemoDatabase();
  const nextDatabase = mutator(deepClone(database)) || database;
  saveDemoDatabase(nextDatabase);
  return nextDatabase;
}

function currentDemoUser() {
  const userId = localStorage.getItem(SESSION_KEY);
  if (!userId) {
    return null;
  }

  const database = loadDemoDatabase();
  return sanitizeUser(database.users.find((user) => user.uid === userId));
}

function subscribeDemo(selector, callback) {
  const emitSelection = () => {
    callback(deepClone(selector(loadDemoDatabase())));
  };

  emitSelection();
  const handler = () => emitSelection();
  window.addEventListener(DATA_EVENT, handler);
  window.addEventListener("storage", handler);

  return () => {
    window.removeEventListener(DATA_EVENT, handler);
    window.removeEventListener("storage", handler);
  };
}

async function initFirebaseBackend() {
  firebaseServices = await getFirebaseServices();
  authReadyPromise = new Promise((resolve) => {
    firebaseServices.authModule.onAuthStateChanged(firebaseServices.auth, async (authUser) => {
      if (!authUser) {
        emitAuthChange(null);
        if (!authResolved) {
          authResolved = true;
          resolve(null);
        }
        return;
      }

      const documentReference = firebaseServices.firestoreModule.doc(
        firebaseServices.db,
        "users",
        authUser.uid
      );
      const snapshot = await firebaseServices.firestoreModule.getDoc(documentReference);
      const userProfile = snapshot.exists()
        ? normalizeUserRecord(snapshot.data(), snapshot.id)
        : null;
      emitAuthChange(userProfile);

      if (!authResolved) {
        authResolved = true;
        resolve(currentUser);
      }
    });
  });
}

function initDemoBackend() {
  ensureDemoDatabase();
  emitAuthChange(currentDemoUser());

  const syncCurrentUser = () => {
    emitAuthChange(currentDemoUser());
  };

  window.addEventListener(DATA_EVENT, syncCurrentUser);
  window.addEventListener("storage", syncCurrentUser);
  authResolved = true;
  authReadyPromise = Promise.resolve(currentUser);
}

export async function initStore() {
  if (initialized) {
    return;
  }

  if (initializingPromise) {
    return initializingPromise;
  }

  initializingPromise = (async () => {
    if (useFirebase) {
      await initFirebaseBackend();
    } else {
      initDemoBackend();
    }

    initialized = true;
  })().finally(() => {
    initializingPromise = null;
  });

  await initializingPromise;
}

export async function waitForAuth() {
  await initStore();
  return authReadyPromise;
}

export function onAuthChange(listener) {
  authListeners.add(listener);
  listener(currentUser);

  return () => {
    authListeners.delete(listener);
  };
}

export async function getCurrentUser() {
  await waitForAuth();
  return currentUser;
}

function normalizeUserRecord(record, id = record?.uid) {
  if (!record) {
    return null;
  }

  return {
    ...record,
    uid: record.uid || id,
  };
}

function normalizeEmergencyRecord(record, id = record?.id) {
  if (!record) {
    return null;
  }

  return {
    ...record,
    id: record.id || id,
    routePath: record.routePath || record.route?.routePath || [],
  };
}

export async function getUsers() {
  await initStore();

  if (!useFirebase) {
    return loadDemoDatabase().users.map((user) => sanitizeUser(user));
  }

  const collectionReference = firebaseServices.firestoreModule.collection(firebaseServices.db, "users");
  const snapshot = await firebaseServices.firestoreModule.getDocs(collectionReference);
  return snapshot.docs.map((documentSnapshot) =>
    normalizeUserRecord(documentSnapshot.data(), documentSnapshot.id)
  );
}

export async function subscribeUsers(callback) {
  await initStore();

  if (!useFirebase) {
    return subscribeDemo((database) => database.users.map((user) => sanitizeUser(user)), callback);
  }

  const collectionReference = firebaseServices.firestoreModule.collection(firebaseServices.db, "users");
  return firebaseServices.firestoreModule.onSnapshot(collectionReference, (snapshot) => {
    callback(
      snapshot.docs.map((documentSnapshot) =>
        normalizeUserRecord(documentSnapshot.data(), documentSnapshot.id)
      )
    );
  });
}

export async function getUserById(userId) {
  await initStore();
  if (!userId) {
    return null;
  }

  if (!useFirebase) {
    const user = loadDemoDatabase().users.find((item) => item.uid === userId);
    return sanitizeUser(user);
  }

  const documentReference = firebaseServices.firestoreModule.doc(firebaseServices.db, "users", userId);
  const snapshot = await firebaseServices.firestoreModule.getDoc(documentReference);
  return snapshot.exists() ? normalizeUserRecord(snapshot.data(), snapshot.id) : null;
}

export async function updateUser(userId, patch) {
  await initStore();
  const updatedAt = nowIso();

  if (!useFirebase) {
    const database = mutateDemoDatabase((draft) => {
      const user = draft.users.find((item) => item.uid === userId);
      if (user) {
        Object.assign(user, patch, { updatedAt });
      }
      return draft;
    });

    const nextUser = database.users.find((item) => item.uid === userId);
    if (currentUser?.uid === userId) {
      emitAuthChange(nextUser);
    }

    return sanitizeUser(nextUser);
  }

  const documentReference = firebaseServices.firestoreModule.doc(firebaseServices.db, "users", userId);
  await firebaseServices.firestoreModule.updateDoc(documentReference, {
    ...patch,
    updatedAt,
  });

  const nextUser = await getUserById(userId);
  if (currentUser?.uid === userId) {
    emitAuthChange(nextUser);
  }
  return nextUser;
}

function buildUserRecord(role, formData, userId) {
  const createdAt = nowIso();
  const baseRecord = {
    uid: userId,
    role,
    email: normalizeEmail(formData.email),
    phone: formData.phone || formData.emergencyContactNumber || "",
    locationLabel: formData.locationLabel || "",
    createdAt,
    updatedAt: createdAt,
  };

  if (role === "patient") {
    return {
      ...baseRecord,
      name: formData.name,
      age: formData.age || "",
      bloodGroup: formData.bloodGroup || "",
      allergies: formData.allergies || "",
      emergencyContact: formData.emergencyContact || "",
    };
  }

  if (role === "driver") {
    const location = parseLocationInput(formData.currentLocation);
    return {
      ...baseRecord,
      name: formData.driverName || formData.name,
      ambulanceNumber: formData.ambulanceNumber || "",
      licenseNumber: formData.licenseNumber || "",
      location,
      locationAccuracy: Number(formData.locationAccuracy || 0),
      locationSource: formData.locationSource || "",
      hospitalId: formData.hospitalId || "",
      hospitalAffiliation: formData.hospitalAffiliation || formData.hospitalName || "",
      status: formData.status || "available",
      lastLocationUpdate: createdAt,
    };
  }

  if (role === "hospital") {
    return {
      ...baseRecord,
      name: formData.hospitalName || formData.name,
      address: formData.address || "",
      emergencyContactNumber: formData.emergencyContactNumber || "",
      ambulanceCount: Number(formData.ambulanceCount || 0),
      availableBeds: Number(formData.availableBeds || 0),
      icuBeds: Number(formData.icuBeds || 0),
      location: parseLocationInput(formData.currentLocation),
    };
  }

  return {
    ...baseRecord,
    name: formData.name || "Track2Save User",
    location: parseLocationInput(formData.currentLocation),
  };
}

function assertUniqueEmail(users, email) {
  const normalized = normalizeEmail(email);
  if (users.some((user) => normalizeEmail(user.email) === normalized)) {
    throw new Error("An account with this email already exists.");
  }
}

async function createDemoAccount(role, formData, options = {}) {
  const database = loadDemoDatabase();
  assertUniqueEmail(database.users, formData.email);
  const userId = uid("user");
  const userRecord = buildUserRecord(role, formData, userId);
  userRecord.password = formData.password;

  mutateDemoDatabase((draft) => {
    draft.users.push(userRecord);
    return draft;
  });

  if (options.autoLogin !== false) {
    localStorage.setItem(SESSION_KEY, userId);
    emitAuthChange(userRecord);
  }

  return sanitizeUser(userRecord);
}

export async function register(role, formData) {
  await initStore();

  if (role === "admin") {
    throw new Error("Admin accounts are provisioned internally. Sign in with an existing admin account.");
  }

  if (!useFirebase) {
    return createDemoAccount(role, formData);
  }

  const credentials = await firebaseServices.authModule.createUserWithEmailAndPassword(
    firebaseServices.auth,
    formData.email,
    formData.password
  );
  const userRecord = buildUserRecord(role, formData, credentials.user.uid);
  const documentReference = firebaseServices.firestoreModule.doc(
    firebaseServices.db,
    "users",
    credentials.user.uid
  );
  await firebaseServices.firestoreModule.setDoc(documentReference, userRecord);
  emitAuthChange(userRecord);
  return userRecord;
}

export async function createManagedAccount(role, formData) {
  await initStore();

  if (!useFirebase) {
    return createDemoAccount(role, formData, { autoLogin: false });
  }

  const secondaryContext = await getSecondaryAuthContext();
  const credentials = await secondaryContext.authModule.createUserWithEmailAndPassword(
    secondaryContext.auth,
    formData.email,
    formData.password
  );

  const userRecord = buildUserRecord(role, formData, credentials.user.uid);
  const documentReference = firebaseServices.firestoreModule.doc(
    firebaseServices.db,
    "users",
    credentials.user.uid
  );
  await firebaseServices.firestoreModule.setDoc(documentReference, userRecord);
  await secondaryContext.authModule.signOut(secondaryContext.auth);
  await secondaryContext.deleteApp(secondaryContext.app);
  return userRecord;
}

export async function login(email, password) {
  await initStore();

  if (!useFirebase) {
    const database = loadDemoDatabase();
    const user = database.users.find(
      (item) => normalizeEmail(item.email) === normalizeEmail(email) && item.password === password
    );

    if (!user) {
      throw new Error("Invalid email or password.");
    }

    localStorage.setItem(SESSION_KEY, user.uid);
    emitAuthChange(user);
    return sanitizeUser(user);
  }

  const credentials = await firebaseServices.authModule.signInWithEmailAndPassword(
    firebaseServices.auth,
    email,
    password
  );
  const user = await getUserById(credentials.user.uid);
  if (!user) {
    await firebaseServices.authModule.signOut(firebaseServices.auth);
    throw new Error(
      "This account is missing its Firestore user profile. Create the matching users document first."
    );
  }
  emitAuthChange(user);
  return user;
}

export async function logout() {
  await initStore();

  if (!useFirebase) {
    localStorage.removeItem(SESSION_KEY);
    emitAuthChange(null);
    return;
  }

  await firebaseServices.authModule.signOut(firebaseServices.auth);
  emitAuthChange(null);
}

export async function resetPassword(email) {
  await initStore();

  if (!useFirebase) {
    const users = loadDemoDatabase().users;
    const account = users.find((user) => normalizeEmail(user.email) === normalizeEmail(email));
    if (!account) {
      throw new Error("No account found for that email.");
    }

    return { message: "Demo mode simulated a password reset email." };
  }

  await firebaseServices.authModule.sendPasswordResetEmail(firebaseServices.auth, email);
  return { message: "Password reset email sent." };
}

export async function getEmergencies() {
  await initStore();

  if (!useFirebase) {
    return sortByDateDesc(loadDemoDatabase().emergencies.map((item) => normalizeEmergencyRecord(item)));
  }

  const collectionReference = firebaseServices.firestoreModule.collection(
    firebaseServices.db,
    "emergencies"
  );
  const snapshot = await firebaseServices.firestoreModule.getDocs(collectionReference);
  return sortByDateDesc(
    snapshot.docs.map((documentSnapshot) =>
      normalizeEmergencyRecord(documentSnapshot.data(), documentSnapshot.id)
    )
  );
}

export async function subscribeEmergencies(callback) {
  await initStore();

  if (!useFirebase) {
    return subscribeDemo(
      (database) => sortByDateDesc(database.emergencies.map((item) => normalizeEmergencyRecord(item))),
      callback
    );
  }

  const collectionReference = firebaseServices.firestoreModule.collection(
    firebaseServices.db,
    "emergencies"
  );
  return firebaseServices.firestoreModule.onSnapshot(collectionReference, (snapshot) => {
    callback(
      sortByDateDesc(
        snapshot.docs.map((documentSnapshot) =>
          normalizeEmergencyRecord(documentSnapshot.data(), documentSnapshot.id)
        )
      )
    );
  });
}

export async function getEmergencyByTrackingId(trackingId) {
  const emergencies = await getEmergencies();
  return emergencies.find((emergency) => emergency.trackingId === String(trackingId)) || null;
}

export async function getEmergencyById(emergencyId) {
  const emergencies = await getEmergencies();
  return emergencies.find((emergency) => emergency.id === emergencyId) || null;
}

export async function updateEmergency(emergencyId, patch) {
  await initStore();
  const updatedAt = nowIso();

  if (!useFirebase) {
    const database = mutateDemoDatabase((draft) => {
      const emergency = draft.emergencies.find((item) => item.id === emergencyId);
      if (emergency) {
        Object.assign(emergency, patch, { updatedAt });
      }
      return draft;
    });

    return normalizeEmergencyRecord(database.emergencies.find((item) => item.id === emergencyId));
  }

  const documentReference = firebaseServices.firestoreModule.doc(
    firebaseServices.db,
    "emergencies",
    emergencyId
  );
  await firebaseServices.firestoreModule.updateDoc(documentReference, {
    ...patch,
    updatedAt,
  });
  return getEmergencyById(emergencyId);
}

function nearestAvailableDriver(users, patientLocation) {
  const drivers = users
    .filter((user) => user.role === "driver" && user.status === "available")
    .map((driver) => {
      const dispatchLocation = resolveDriverDispatchLocation(users, driver);
      if (!dispatchLocation) {
        return null;
      }

      return {
        driver,
        dispatchLocation,
        distanceKm: haversineDistanceKm(dispatchLocation, patientLocation),
      };
    })
    .filter(Boolean);

  if (!drivers.length) {
    return null;
  }

  const bestMatch = drivers.sort((left, right) => left.distanceKm - right.distanceKm)[0];
  return {
    ...bestMatch.driver,
    dispatchLocation: bestMatch.dispatchLocation,
  };
}

function resolveDriverDispatchLocation(users, driver) {
  const driverLocation = parseLocationInput(driver?.location);
  if (driverLocation) {
    return driverLocation;
  }

  const affiliatedHospital = resolveAffiliatedHospital(users, driver);
  return parseLocationInput(affiliatedHospital?.location);
}

function resolveAffiliatedHospital(users, driver) {
  if (!driver) {
    return null;
  }

  const hospitals = users.filter(
    (user) => user.role === "hospital" && parseLocationInput(user.location)
  );

  if (driver.hospitalId) {
    const directMatch = hospitals.find((hospital) => hospital.uid === driver.hospitalId);
    if (directMatch) {
      return directMatch;
    }
  }

  const affiliation = normalizeEmail(driver.hospitalAffiliation || "");
  if (!affiliation) {
    return null;
  }

  return (
    hospitals.find((hospital) => {
      const hospitalName = normalizeEmail(hospital.name || "");
      return hospitalName === affiliation || hospitalName.includes(affiliation) || affiliation.includes(hospitalName);
    }) || null
  );
}

function bestHospital(users, patientLocation, assignedDriver) {
  const hospitals = users.filter(
    (user) =>
      user.role === "hospital" &&
      Number(user.availableBeds || 0) > 0 &&
      parseLocationInput(user.location)
  );

  if (!hospitals.length) {
    return null;
  }

  const affiliated = resolveAffiliatedHospital(hospitals, assignedDriver);
  if (affiliated && Number(affiliated.availableBeds || 0) > 0) {
    return affiliated;
  }

  return hospitals
    .map((hospital) => ({
      hospital,
      distanceKm: haversineDistanceKm(hospital.location, patientLocation),
    }))
    .sort((left, right) => left.distanceKm - right.distanceKm)[0].hospital;
}

export async function dispatchEmergency({
  patientId,
  patientLocation,
  patientLocationAccuracy = 0,
  patientLocationSource = "",
  notifyPolice = false,
  clearTrafficSignals = false,
}) {
  const emergencies = await getEmergencies();
  const activeEmergency = emergencies.find(
    (emergency) => emergency.patientId === patientId && isActiveEmergency(emergency)
  );

  if (activeEmergency) {
    return { ...activeEmergency, alreadyActive: true };
  }

  const [users, patient] = await Promise.all([getUsers(), getUserById(patientId)]);
  const assignedDriver = nearestAvailableDriver(users, patientLocation);

  if (!assignedDriver) {
    const availableDrivers = users.filter(
      (user) => user.role === "driver" && user.status === "available"
    );
    if (availableDrivers.length) {
      throw new Error(
        "An available driver exists, but their live/base location is missing. Update the driver GPS or affiliated hospital location from the control room."
      );
    }
    throw new Error("No available driver could be dispatched right now.");
  }

  const assignedHospital = bestHospital(users, patientLocation, assignedDriver);
  const dispatchOrigin = assignedDriver.dispatchLocation || assignedDriver.location || DEFAULT_CENTER;
  const route = await getSmartRoute(dispatchOrigin, patientLocation);
  const emergencyId = uid("emergency");
  const createdAt = nowIso();

  const emergencyRecord = {
    id: emergencyId,
    trackingId: generateTrackingId(emergencies.map((item) => item.trackingId)),
    patientId,
    patientName: getFullName(patient),
    patientPhone: patient?.phone || "",
    patientLocation,
    patientLocationAccuracy,
    patientLocationSource,
    notifyPolice,
    clearTrafficSignals,
    driverId: assignedDriver.uid,
    driverName: getFullName(assignedDriver),
    driverPhone: assignedDriver.phone || "",
    ambulanceNumber: assignedDriver.ambulanceNumber || "",
    hospitalId: assignedHospital?.uid || "",
    hospitalName: assignedHospital?.name || "Manual Coordination",
    status: "en_route",
    patientDetails: {},
    routePath: route.routePath,
    trafficLevel: route.trafficLevel,
    distanceKm: route.distanceKm,
    etaMinutes: route.etaMinutes,
    routeEngine: route.routeEngine || "simulated",
    bedPrepared: false,
    autoAssigned: true,
    createdAt,
    updatedAt: createdAt,
  };

  if (!useFirebase) {
    mutateDemoDatabase((draft) => {
      draft.emergencies.unshift(emergencyRecord);
      const driver = draft.users.find((user) => user.uid === assignedDriver.uid);
      if (driver) {
        driver.status = "on_trip";
        if (!driver.location && assignedDriver.dispatchLocation) {
          driver.location = assignedDriver.dispatchLocation;
          driver.locationAccuracy = 0;
          driver.locationSource = "hospital base";
          driver.lastLocationUpdate = createdAt;
        }
        driver.updatedAt = createdAt;
      }
      return draft;
    });
  } else {
    const emergencyReference = firebaseServices.firestoreModule.doc(
      firebaseServices.db,
      "emergencies",
      emergencyId
    );
    await firebaseServices.firestoreModule.setDoc(emergencyReference, emergencyRecord);
    const driverPatch = { status: "on_trip" };
    if (!assignedDriver.location && assignedDriver.dispatchLocation) {
      Object.assign(driverPatch, {
        location: assignedDriver.dispatchLocation,
        locationAccuracy: 0,
        locationSource: "hospital base",
        lastLocationUpdate: createdAt,
      });
    }
    await updateUser(assignedDriver.uid, driverPatch);
  }

  return emergencyRecord;
}

export async function savePatientEmergencyDetails(emergencyId, details) {
  return updateEmergency(emergencyId, {
    patientDetails: details,
    detailSubmittedAt: nowIso(),
  });
}

export async function updateDriverStatus(driverId, status) {
  return updateUser(driverId, { status });
}

export async function updateDriverLocation(driverId, location) {
  const normalizedLocation = parseLocationInput(location);
  if (!normalizedLocation) {
    throw new Error("A valid driver location is required.");
  }

  const locationAccuracy = Number(location?.accuracy || 0);
  const locationSource = location?.source || "";

  const updatedDriver = await updateUser(driverId, {
    location: normalizedLocation,
    locationAccuracy,
    locationSource,
    lastLocationUpdate: nowIso(),
  });

  const emergencies = await getEmergencies();
  const activeEmergency = emergencies.find(
    (emergency) => emergency.driverId === driverId && ACTIVE_EMERGENCY_STATUSES.includes(emergency.status)
  );

  if (!activeEmergency) {
    return updatedDriver;
  }

  const route = await getSmartRoute(normalizedLocation, activeEmergency.patientLocation);
  await updateEmergency(activeEmergency.id, {
    routePath: route.routePath,
    trafficLevel: route.trafficLevel,
    distanceKm: route.distanceKm,
    etaMinutes: route.etaMinutes,
    routeEngine: route.routeEngine || "simulated",
    status: route.distanceKm <= 0.18 ? "arrived" : "en_route",
  });

  return updatedDriver;
}

export async function completeEmergency(emergencyId) {
  const emergency = await getEmergencyById(emergencyId);
  if (!emergency) {
    throw new Error("Trip not found.");
  }

  await updateEmergency(emergencyId, {
    status: "completed",
    completedAt: nowIso(),
  });

  if (emergency.driverId) {
    await updateUser(emergency.driverId, { status: "available" });
  }

  return getEmergencyById(emergencyId);
}

export async function prepareHospitalBed(emergencyId, hospitalId) {
  const emergency = await getEmergencyById(emergencyId);
  const hospital = await getUserById(hospitalId);

  if (!hospital) {
    throw new Error("Hospital account not found.");
  }

  if (emergency?.bedPrepared) {
    return {
      ...(emergency || {}),
      hospitalAvailableBeds: hospital.availableBeds,
    };
  }

  await updateEmergency(emergencyId, {
    bedPrepared: true,
    bedPreparedAt: nowIso(),
  });

  const availableBeds = Math.max(0, Number(hospital.availableBeds || 0) - 1);
  await updateUser(hospitalId, { availableBeds });

  return {
    ...(emergency || {}),
    bedPrepared: true,
    hospitalAvailableBeds: availableBeds,
  };
}
