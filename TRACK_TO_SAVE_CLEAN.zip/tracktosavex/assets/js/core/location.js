import { DEFAULT_CENTER } from "./config.js";

const GEO_OPTIONS = Object.freeze({
  enableHighAccuracy: true,
  timeout: 15000,
  maximumAge: 0,
});

const TRANSIENT_LOCATION_PATTERN = /kCLErrorLocationUnknown|location unknown|position unavailable/i;
let lastKnownLocationFix = null;

function normalizePosition(position) {
  lastKnownLocationFix = {
    lat: position.coords.latitude,
    lng: position.coords.longitude,
    accuracy: Math.round(position.coords.accuracy || 0),
    capturedAt: new Date(position.timestamp || Date.now()).toISOString(),
    source: "gps",
  };

  return lastKnownLocationFix;
}

function splitLocationOptions(options = {}) {
  const {
    retryAttempts = 2,
    retryDelayMs = 1400,
    transientErrorThreshold = 3,
    ...geoOptions
  } = options;

  return {
    retryAttempts,
    retryDelayMs,
    transientErrorThreshold,
    geoOptions: {
      ...GEO_OPTIONS,
      ...geoOptions,
    },
  };
}

function isTransientLocationError(error) {
  const message = String(error?.message || "");
  return Number(error?.code) === 2 || TRANSIENT_LOCATION_PATTERN.test(message);
}

function buildLocationError(error) {
  const code = Number(error?.code || 0);
  let message = "Unable to determine your location right now.";

  if (code === 1) {
    message = "Location permission is blocked. Allow GPS access in your browser and device settings.";
  } else if (code === 3) {
    message =
      "Location request timed out. Move to an open area, keep GPS on, and try again.";
  } else if (isTransientLocationError(error)) {
    message =
      "GPS is still connecting to the device location service. Keep location services on and try again in a few seconds.";
  } else if (typeof error?.message === "string" && error.message.trim()) {
    message = error.message;
  }

  const wrapped = new Error(message);
  wrapped.code = code || error?.code || "";
  wrapped.isTransient = isTransientLocationError(error);
  wrapped.originalError = error;
  return wrapped;
}

function requestCurrentPosition(resolve, reject, geoOptions, attemptsLeft, retryDelayMs) {
  navigator.geolocation.getCurrentPosition(
    (position) => {
      resolve(normalizePosition(position));
    },
    (error) => {
      if (isTransientLocationError(error) && attemptsLeft > 0) {
        window.setTimeout(() => {
          requestCurrentPosition(resolve, reject, geoOptions, attemptsLeft - 1, retryDelayMs);
        }, retryDelayMs);
        return;
      }

      reject(buildLocationError(error));
    },
    geoOptions
  );
}

export function getBrowserLocation(options = {}) {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("Geolocation is not supported in this browser."));
      return;
    }

    const { retryAttempts, retryDelayMs, geoOptions } = splitLocationOptions(options);
    requestCurrentPosition(resolve, reject, geoOptions, retryAttempts, retryDelayMs);
  });
}

export function watchBrowserLocation({ onUpdate, onError } = {}, options = {}) {
  if (!navigator.geolocation) {
    onError?.(new Error("Geolocation is not supported in this browser."));
    return () => {};
  }

  const { geoOptions, transientErrorThreshold } = splitLocationOptions(options);
  let transientErrorCount = 0;

  const watchId = navigator.geolocation.watchPosition(
    (position) => {
      transientErrorCount = 0;
      onUpdate?.(normalizePosition(position));
    },
    (error) => {
      const wrapped = buildLocationError(error);
      if (wrapped.isTransient && transientErrorCount < transientErrorThreshold - 1) {
        transientErrorCount += 1;
        return;
      }

      transientErrorCount = 0;
      onError?.(wrapped);
    },
    geoOptions
  );

  return () => {
    navigator.geolocation.clearWatch(watchId);
  };
}

export function toPlainLocation(locationFix) {
  if (!locationFix) {
    return null;
  }

  return {
    lat: locationFix.lat,
    lng: locationFix.lng,
  };
}

export function getCachedLocation(maxAgeMs = 120000) {
  if (!lastKnownLocationFix?.capturedAt) {
    return null;
  }

  const capturedAt = new Date(lastKnownLocationFix.capturedAt).getTime();
  if (!Number.isFinite(capturedAt)) {
    return null;
  }

  return Date.now() - capturedAt <= maxAgeMs ? { ...lastKnownLocationFix } : null;
}

export function isRecentLocationFix(locationFix, maxAgeMs = 120000) {
  if (!locationFix?.capturedAt) {
    return false;
  }

  const capturedAt = new Date(locationFix.capturedAt).getTime();
  if (!Number.isFinite(capturedAt)) {
    return false;
  }

  return Date.now() - capturedAt <= maxAgeMs;
}

export async function getBestAvailableLocation(options = {}) {
  const {
    cachedMaxAgeMs = 120000,
    warmupTimeoutMs = 26000,
    fallbackToCached = true,
    ...geoOptions
  } = options;

  const cachedLocation = getCachedLocation(cachedMaxAgeMs);
  if (cachedLocation) {
    return cachedLocation;
  }

  try {
    return await getBrowserLocation({
      timeout: 22000,
      maximumAge: 15000,
      retryAttempts: 3,
      retryDelayMs: 1800,
      ...geoOptions,
    });
  } catch (error) {
    if (!error?.isTransient && Number(error?.code) !== 3) {
      throw error;
    }
  }

  return new Promise((resolve, reject) => {
    let settled = false;
    let stopWatching = () => {};
    let timeoutId = 0;

    const finish = (callback, value) => {
      if (settled) {
        return;
      }

      settled = true;
      stopWatching();
      window.clearTimeout(timeoutId);
      callback(value);
    };

    stopWatching = watchBrowserLocation(
      {
        onUpdate: (locationFix) => {
          finish(resolve, locationFix);
        },
        onError: (error) => {
          if (!error?.isTransient) {
            finish(reject, error);
          }
        },
      },
      {
        timeout: Math.max(geoOptions.timeout || 22000, warmupTimeoutMs),
        maximumAge: 10000,
        transientErrorThreshold: 6,
        ...geoOptions,
      }
    );

    timeoutId = window.setTimeout(() => {
      const fallbackLocation = fallbackToCached ? getCachedLocation(cachedMaxAgeMs * 3) : null;
      if (fallbackLocation) {
        finish(resolve, fallbackLocation);
        return;
      }

      finish(
        reject,
        new Error(
          "Live GPS is still warming up. Keep location services on, wait a few seconds, then try again."
        )
      );
    }, warmupTimeoutMs);
  });
}

export function formatLocationAccuracy(locationFix) {
  const accuracy =
    typeof locationFix === "number"
      ? locationFix
      : Number(locationFix?.accuracy || 0);

  if (!accuracy) {
    return "Accuracy unavailable";
  }

  if (accuracy < 1000) {
    return `Accuracy ${accuracy} m`;
  }

  return `Accuracy ${(accuracy / 1000).toFixed(1)} km`;
}

export async function getLocationWithFallback() {
  try {
    return await getBrowserLocation();
  } catch (error) {
    return {
      ...DEFAULT_CENTER,
      accuracy: 0,
      capturedAt: new Date().toISOString(),
      source: "fallback",
    };
  }
}
