import { parseLocationInput } from "./utils.js";

const NOMINATIM_SEARCH_ENDPOINT = "https://nominatim.openstreetmap.org/search";
const NOMINATIM_REVERSE_ENDPOINT = "https://nominatim.openstreetmap.org/reverse";
const DEFAULT_COUNTRY_CODE = "in";

function buildLocationLabel(result) {
  const address = result?.address || {};
  return (
    [
      address.city || address.town || address.village || address.hamlet || address.county,
      address.state,
    ]
      .filter(Boolean)
      .join(", ") ||
    result?.display_name ||
    ""
  );
}

export function stringifyCoordinateStorage(location) {
  if (!location) {
    return "";
  }

  return `${Number(location.lat).toFixed(5)}, ${Number(location.lng).toFixed(5)}`;
}

export async function geocodeCityName(query, options = {}) {
  const searchQuery = String(query || "").trim();
  if (!searchQuery) {
    throw new Error("Enter a city or area name first.");
  }

  if (typeof fetch === "undefined") {
    throw new Error("Map search is unavailable in this browser.");
  }

  const url = new URL(NOMINATIM_SEARCH_ENDPOINT);
  url.searchParams.set("format", "jsonv2");
  url.searchParams.set("q", searchQuery);
  url.searchParams.set("limit", "1");
  url.searchParams.set("addressdetails", "1");
  url.searchParams.set("countrycodes", options.countryCode || DEFAULT_COUNTRY_CODE);

  const response = await fetch(url.toString(), {
    headers: {
      Accept: "application/json",
    },
  });

  if (!response.ok) {
    throw new Error("Unable to fetch the city location right now.");
  }

  const payload = await response.json();
  const result = payload?.[0];

  if (!result) {
    throw new Error("City not found. Try a clearer city or area name.");
  }

  const location = {
    lat: Number(result.lat),
    lng: Number(result.lon),
  };

  return {
    ...location,
    label: buildLocationLabel(result),
    displayName: result.display_name || searchQuery,
    currentLocation: stringifyCoordinateStorage(location),
  };
}

export async function reverseGeocodeLocation(location, options = {}) {
  const parsedLocation = parseLocationInput(location);
  if (!parsedLocation) {
    return null;
  }

  if (typeof fetch === "undefined") {
    return {
      ...parsedLocation,
      label: "",
      currentLocation: stringifyCoordinateStorage(parsedLocation),
    };
  }

  const url = new URL(NOMINATIM_REVERSE_ENDPOINT);
  url.searchParams.set("format", "jsonv2");
  url.searchParams.set("lat", parsedLocation.lat);
  url.searchParams.set("lon", parsedLocation.lng);
  url.searchParams.set("addressdetails", "1");
  url.searchParams.set("zoom", "12");
  url.searchParams.set("countrycodes", options.countryCode || DEFAULT_COUNTRY_CODE);

  try {
    const response = await fetch(url.toString(), {
      headers: {
        Accept: "application/json",
      },
    });

    if (!response.ok) {
      throw new Error("Reverse geocoding failed.");
    }

    const payload = await response.json();
    return {
      ...parsedLocation,
      label: buildLocationLabel(payload),
      displayName: payload?.display_name || "",
      currentLocation: stringifyCoordinateStorage(parsedLocation),
    };
  } catch (error) {
    return {
      ...parsedLocation,
      label: "",
      displayName: "",
      currentLocation: stringifyCoordinateStorage(parsedLocation),
    };
  }
}
