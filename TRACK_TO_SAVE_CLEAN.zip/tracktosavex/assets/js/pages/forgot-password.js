import { explainAppError } from "../core/errors.js";
import { bootstrapPage } from "../core/shell.js";
import { resetPassword } from "../core/store.js";
import { showToast } from "../core/ui.js";

document.addEventListener("DOMContentLoaded", async () => {
  await bootstrapPage({ currentPage: "forgot-password" });

  const form = document.getElementById("forgot-password-form");
  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    try {
      const formData = new FormData(form);
      const result = await resetPassword(formData.get("email"));
      showToast(result.message, "success");
    } catch (error) {
      showToast(explainAppError(error), "error");
    }
  });
});
