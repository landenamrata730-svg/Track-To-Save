import {
  clearDynamicLayers,
  createMap,
  fitToPoints,
  upsertCircle,
  upsertMarker,
  upsertPolyline,
} from "../core/maps.js";
import { explainAppError } from "../core/errors.js";
import {
  formatLocationAccuracy,
  getBestAvailableLocation,
  isRecentLocationFix,
  toPlainLocation,
  watchBrowserLocation,
} from "../core/location.js";
import { renderRequestCards } from "../core/renderers.js";
import { bootstrapPage } from "../core/shell.js";
import {
  dispatchEmergency,
  savePatientEmergencyDetails,
  subscribeEmergencies,
  subscribeUsers,
} from "../core/store.js";
import { buildShareUrl, copyText, isActiveEmergency, stringifyLocation } from "../core/utils.js";
import { showModal, showToast } from "../core/ui.js";

document.addEventListener("DOMContentLoaded", async () => {
  const { user } = await bootstrapPage({
    currentPage: "book-ambulance",
    requireAuth: true,
    allowedRoles: ["patient"],
  });
  if (!user) {
    return;
  }

  const bookButton = document.getElementById("book-ambulance-button");
  const captureButton = document.getElementById("capture-patient-location");
  const locationStatusTarget = document.getElementById("booking-location-status");
  const summaryTarget = document.getElementById("booking-summary");
  const detailsForm = document.getElementById("patient-details-form");
  const detailsPlaceholder = document.getElementById("patient-details-placeholder");
  const trackingBox = document.getElementById("booking-tracking-box");
  const trackingIdTarget = document.getElementById("booking-tracking-id");
  const map = createMap("booking-map", { scrollWheelZoom: true });

  let currentLocationFix = user.location
    ? {
        ...user.location,
        accuracy: Number(user.locationAccuracy || 0),
        source: user.locationSource || "saved profile",
      }
    : null;
  let locationMode = currentLocationFix ? "saved" : "gps";
  let users = [];
  let emergencies = [];
  let stopLocationWatch = () => {};
  let gpsCaptureInFlight = false;

  const getActiveEmergency = () =>
    emergencies.find((emergency) => emergency.patientId === user.uid && isActiveEmergency(emergency));

  function renderLocationStatus(activeEmergency) {
    if (activeEmergency) {
      locationStatusTarget.innerHTML = `
        <div class="info-banner">
          <div class="icon-circle">L</div>
          <div>
            <strong>Pickup locked for active emergency</strong>
            <p>${stringifyLocation(activeEmergency.patientLocation)}${activeEmergency.patientLocationAccuracy ? ` • ${formatLocationAccuracy(activeEmergency.patientLocationAccuracy)}` : ""}</p>
          </div>
        </div>
      `;
      bookButton.disabled = true;
      return;
    }

    if (!currentLocationFix) {
      locationStatusTarget.innerHTML = `
        <div class="alert-strip">
          <div class="icon-circle">!</div>
          <div>
            <strong>Pickup point not confirmed yet</strong>
            <p>Allow GPS access or tap the map to place the exact ambulance pickup location before booking.</p>
          </div>
        </div>
      `;
      bookButton.disabled = true;
      return;
    }

    const sourceLabel =
      locationMode === "manual" ? "map pin" : currentLocationFix.source || "gps";

    locationStatusTarget.innerHTML = `
      <div class="info-banner">
        <div class="icon-circle">P</div>
        <div>
          <strong>Pickup point ready</strong>
          <p>${stringifyLocation(currentLocationFix)} • ${formatLocationAccuracy(currentLocationFix)} • Source ${sourceLabel}</p>
        </div>
      </div>
    `;
    bookButton.disabled = false;
  }

  function populateDetailsForm(emergency) {
    detailsForm.classList.toggle("hidden", !emergency);
    detailsPlaceholder.classList.toggle("hidden", Boolean(emergency));

    if (!emergency) {
      return;
    }

    const details = emergency.patientDetails || {};
    document.getElementById("patient-detail-age").value = details.age || user.age || "";
    document.getElementById("patient-detail-blood").value =
      details.bloodGroup || user.bloodGroup || "";
    document.getElementById("patient-detail-condition").value = details.condition || "";
    document.getElementById("patient-detail-notes").value = details.notes || user.allergies || "";
  }

  function render() {
    const activeEmergency = getActiveEmergency();
    const driver = users.find((candidate) => candidate.uid === activeEmergency?.driverId);
    const hospital = users.find((candidate) => candidate.uid === activeEmergency?.hospitalId);

    populateDetailsForm(activeEmergency);
    renderLocationStatus(activeEmergency);

    trackingBox.classList.toggle("hidden", !activeEmergency);
    if (activeEmergency) {
      trackingIdTarget.textContent = activeEmergency.trackingId;
    }

    if (activeEmergency) {
      const shareUrl = buildShareUrl(activeEmergency.trackingId);
      renderRequestCards(summaryTarget, [
        {
          title: "Dispatch confirmed",
          subtitle: `Patient pickup at ${stringifyLocation(activeEmergency.patientLocation)}`,
          badge: activeEmergency.status,
          badgeTone: "tone-danger",
          body: `
            <div class="key-value-grid">
              <div class="key-value">
                <strong>Driver</strong>
                <span>${driver?.name || activeEmergency.driverName || "Assigned"}</span>
              </div>
              <div class="key-value">
                <strong>Hospital</strong>
                <span>${hospital?.name || activeEmergency.hospitalName || "Pending"}</span>
              </div>
              <div class="key-value">
                <strong>ETA</strong>
                <span>${activeEmergency.etaMinutes || 0} min</span>
              </div>
              <div class="key-value">
                <strong>Pickup accuracy</strong>
                <span>${formatLocationAccuracy(activeEmergency.patientLocationAccuracy)}</span>
              </div>
              <div class="key-value">
                <strong>Police alert</strong>
                <span>${activeEmergency.notifyPolice ? "Requested" : "Standard dispatch"}</span>
              </div>
              <div class="key-value">
                <strong>Signal clearance</strong>
                <span>${activeEmergency.clearTrafficSignals ? "Requested" : "Normal traffic flow"}</span>
              </div>
            </div>
            <div class="button-row app-note">
              <a class="btn btn-primary btn-sm" href="live-tracking.html?trackingId=${activeEmergency.trackingId}">View Live Tracking</a>
              <button class="btn btn-ghost btn-sm" type="button" data-copy-share-link="${shareUrl}">Copy Share Link</button>
            </div>
          `,
        },
      ]);
    } else {
      renderRequestCards(summaryTarget, [
        {
          title: "Ready to dispatch",
          subtitle: currentLocationFix
            ? `Pickup point confirmed at ${stringifyLocation(currentLocationFix)}`
            : "Capture your GPS location or tap the map to set the pickup point.",
          badge: currentLocationFix ? "Location Ready" : "Awaiting GPS",
          badgeTone: currentLocationFix ? "tone-success" : "tone-warning",
          body: `
            <div class="info-banner">
              <div class="icon-circle">i</div>
              <div>
                <strong>Automatic dispatch</strong>
                <p>The platform will find the nearest available driver, notify the hospital, and generate your family tracking ID.</p>
              </div>
            </div>
          `,
        },
      ]);
    }

    if (!map) {
      return;
    }

    clearDynamicLayers(map);

    if (activeEmergency) {
      upsertMarker(map, "patient", activeEmergency.patientLocation, {
        label: "P",
        color: "#ef4444",
        popup: "Pickup location",
      });
      upsertCircle(map, "patient", activeEmergency.patientLocation, {
        color: "#ef4444",
        fillColor: "#ef4444",
        radius: activeEmergency.patientLocationAccuracy || 80,
      });

      if (driver?.location) {
        upsertMarker(map, "driver", driver.location, {
          label: "A",
          color: "#0f6fff",
          popup: driver.name,
        });
      }

      if (hospital?.location) {
        upsertMarker(map, "hospital", hospital.location, {
          label: "H",
          color: "#16a34a",
          popup: hospital.name,
        });
      }

      if (activeEmergency.routePath?.length) {
        upsertPolyline(map, "route", activeEmergency.routePath, {
          color:
            activeEmergency.trafficLevel === "heavy"
              ? "#ef4444"
              : activeEmergency.trafficLevel === "moderate"
                ? "#f59e0b"
                : "#16a34a",
        });
      }

      fitToPoints(
        map,
        [activeEmergency.patientLocation, driver?.location, hospital?.location].filter(Boolean)
      );
      return;
    }

    if (currentLocationFix) {
      upsertMarker(map, "patient-preview", currentLocationFix, {
        label: "P",
        color: "#ef4444",
        popup: "Selected pickup point",
      });
      upsertCircle(map, "patient-preview", currentLocationFix, {
        color: "#ef4444",
        fillColor: "#ef4444",
        radius: currentLocationFix.accuracy || 80,
      });
      fitToPoints(map, [currentLocationFix], { zoom: 16, maxZoom: 17 });
    }
  }

  function setCurrentLocation(locationFix, sourceMode) {
    if (!locationFix) {
      return;
    }

    currentLocationFix = locationFix;
    locationMode = sourceMode;
    render();
  }

  if (map) {
    map.on("click", (event) => {
      if (getActiveEmergency()) {
        return;
      }

      setCurrentLocation(
        {
          lat: event.latlng.lat,
          lng: event.latlng.lng,
          accuracy: 0,
          capturedAt: new Date().toISOString(),
          source: "manual map pin",
        },
        "manual"
      );
      showToast("Pickup point adjusted on the map.", "success");
    });
  }

  stopLocationWatch = watchBrowserLocation({
    onUpdate: (locationFix) => {
      if (getActiveEmergency() || locationMode === "manual") {
        return;
      }

      setCurrentLocation(locationFix, "gps");
    },
    onError: () => {},
  }, {
    timeout: 30000,
    maximumAge: 10000,
    transientErrorThreshold: 6,
  });

  window.addEventListener(
    "beforeunload",
    () => {
      stopLocationWatch();
    },
    { once: true }
  );

  captureButton.addEventListener("click", async () => {
    if (gpsCaptureInFlight) {
      return;
    }

    if (currentLocationFix && locationMode !== "manual" && isRecentLocationFix(currentLocationFix, 150000)) {
      setCurrentLocation(
        {
          ...currentLocationFix,
          source: currentLocationFix.source || "gps",
        },
        "gps"
      );
      showToast("Using your latest live GPS fix.", "success");
      return;
    }

    gpsCaptureInFlight = true;
    captureButton.disabled = true;
    const originalLabel = captureButton.textContent;
    captureButton.textContent = "Capturing GPS...";

    try {
      const locationFix = await getBestAvailableLocation({
        timeout: 22000,
        warmupTimeoutMs: 28000,
      });
      setCurrentLocation(locationFix, "gps");
      showToast("Patient location captured from GPS.", "success");
    } catch (error) {
      showToast(
        `${explainAppError(error)} If you are indoors, move near a window or open area and try again. You can still tap the map to place the pickup pin manually.`,
        "error"
      );
    } finally {
      gpsCaptureInFlight = false;
      captureButton.disabled = false;
      captureButton.textContent = originalLabel;
    }
  });

  bookButton.addEventListener("click", async () => {
    const existingEmergency = getActiveEmergency();
    if (existingEmergency) {
      showToast("You already have an active ambulance request.", "error");
      render();
      return;
    }

    if (!currentLocationFix) {
      showToast("Set the pickup point with GPS or by tapping the map before booking.", "error");
      return;
    }

    const modalResult = await showModal({
      title: "Confirm ambulance booking",
      message:
        "Track2Save will dispatch the nearest ambulance, notify the hospital, and lock this pickup point immediately.",
      detailsHtml:
        "<p class=\"modal-note\">Choose any extra emergency coordination alerts that should be sent with this dispatch.</p>",
      fields: [
        {
          type: "checkbox",
          name: "notifyPolice",
          label: "Send police support alert",
          description: "Notify police control so they can support emergency movement when needed.",
        },
        {
          type: "checkbox",
          name: "clearTrafficSignals",
          label: "Request traffic signal clearance",
          description: "Flag connected traffic operations to help clear the ambulance route.",
        },
      ],
      confirmText: "Dispatch Ambulance",
    });

    if (!modalResult?.confirmed) {
      return;
    }

    try {
      const emergency = await dispatchEmergency({
        patientId: user.uid,
        patientLocation: toPlainLocation(currentLocationFix),
        patientLocationAccuracy: Number(currentLocationFix.accuracy || 0),
        patientLocationSource: currentLocationFix.source || locationMode,
        notifyPolice: Boolean(modalResult.values?.notifyPolice),
        clearTrafficSignals: Boolean(modalResult.values?.clearTrafficSignals),
      });

      showToast(
        emergency.alreadyActive
          ? "An active emergency already exists for your account."
          : `Ambulance dispatched. Tracking ID ${emergency.trackingId}.`,
        "success"
      );
    } catch (error) {
      showToast(explainAppError(error), "error");
    }
  });

  detailsForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const activeEmergency = getActiveEmergency();
    if (!activeEmergency) {
      showToast("Book an ambulance before sending patient details.", "error");
      return;
    }

    try {
      const payload = Object.fromEntries(new FormData(detailsForm).entries());
      await savePatientEmergencyDetails(activeEmergency.id, payload);
      showToast("Patient details sent to the hospital.", "success");
    } catch (error) {
      showToast(explainAppError(error), "error");
    }
  });

  summaryTarget.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-copy-share-link]");
    if (!button) {
      return;
    }

    const copied = await copyText(button.dataset.copyShareLink);
    showToast(
      copied ? "Share link copied." : "Clipboard is unavailable.",
      copied ? "success" : "error"
    );
  });

  await subscribeUsers((nextUsers) => {
    users = nextUsers;
    render();
  });

  await subscribeEmergencies((nextEmergencies) => {
    emergencies = nextEmergencies;
    render();
  });
});
