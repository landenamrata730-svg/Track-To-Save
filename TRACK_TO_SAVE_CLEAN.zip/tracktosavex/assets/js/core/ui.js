import { APP_NAME, DASHBOARD_PATHS, PUBLIC_LINKS, ROLE_LABELS, ROLE_NAV } from "./config.js";
import { appSettings } from "../firebase-config.js";
import { escapeHtml } from "./utils.js";

const BRAND_LOGO_PATH = "assets/img/track2save-logo.svg";

function getDashboardLink(user) {
  if (!user?.role) {
    return "login.html";
  }

  return DASHBOARD_PATHS[user.role] || "index.html";
}

function renderLinks(currentPage, user) {
  const links = user?.role ? ROLE_NAV[user.role] || [] : PUBLIC_LINKS;

  return links
    .map((link) => {
      const isActive = link.key === currentPage;
      return `<a class="nav-link${isActive ? " active" : ""}" href="${link.href}">${escapeHtml(
        link.label
      )}</a>`;
    })
    .join("");
}

function modeLabel() {
  return "Live System";
}

function getFooterLinks(user) {
  const sourceLinks = user?.role
    ? [...PUBLIC_LINKS, ...(ROLE_NAV[user.role] || [])]
    : [...PUBLIC_LINKS, { href: "forgot-password.html", label: "Support", key: "support" }];

  const seen = new Set();
  return sourceLinks.filter((link) => {
    if (seen.has(link.href)) {
      return false;
    }
    seen.add(link.href);
    return true;
  });
}

export function renderShell({ currentPage, user }) {
  const headerTarget = document.querySelector("[data-site-header]");
  const footerTarget = document.querySelector("[data-site-footer]");

  if (headerTarget) {
    headerTarget.innerHTML = `
      <div class="container nav-shell">
        <a class="brand" href="index.html">
          <span class="brand-mark">
            <img src="${BRAND_LOGO_PATH}" alt="${APP_NAME} logo" />
          </span>
          <span>
            <strong>${APP_NAME}</strong>
            <small>Smart Ambulance Tracking</small>
          </span>
        </a>
        <nav class="nav-links">
          ${renderLinks(currentPage, user)}
        </nav>
        <div class="nav-actions">
          <span class="mode-pill">${modeLabel()}</span>
          ${
            user
              ? `
                <a class="chip-link" href="${getDashboardLink(user)}">${escapeHtml(
                  ROLE_LABELS[user.role] || "Dashboard"
                )}</a>
                <button class="btn btn-ghost btn-sm" data-logout-button type="button">Logout</button>
              `
              : `
                <a class="btn btn-primary btn-sm" href="login.html">Get Started</a>
              `
          }
        </div>
      </div>
    `;
  }

  if (footerTarget) {
    footerTarget.innerHTML = `
      <div class="container footer-shell">
        <div class="footer-brand">
          <div class="brand">
            <span class="brand-mark brand-mark-footer">
              <img src="${BRAND_LOGO_PATH}" alt="${APP_NAME} logo" />
            </span>
            <span>
              <strong>${APP_NAME}</strong>
              <small>Smart Ambulance Tracking</small>
            </span>
          </div>
          <p>Real-time ambulance dispatch, hospital alerts, and family tracking from one connected emergency platform.</p>
          <span class="footer-team">Developed by CODECRAFTER'S</span>
        </div>
        <div class="footer-links">
          <strong>Quick Links</strong>
          ${getFooterLinks(user)
            .map(
              (link) =>
                `<a href="${link.href}" class="footer-link">${escapeHtml(link.label)}</a>`
            )
            .join("")}
        </div>
        <div class="footer-meta">
          <span>Status: ${modeLabel()}</span>
          <span>Driver updates every ${appSettings.driverLocationIntervalMs / 1000}s</span>
          <span>Default response region: Pandharpur</span>
        </div>
      </div>
    `;
  }
}

export function showToast(message, type = "info") {
  let container = document.querySelector("[data-toast-stack]");

  if (!container) {
    container = document.createElement("div");
    container.dataset.toastStack = "true";
    container.className = "toast-stack";
    document.body.appendChild(container);
  }

  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  container.appendChild(toast);

  requestAnimationFrame(() => toast.classList.add("visible"));

  setTimeout(() => {
    toast.classList.remove("visible");
    setTimeout(() => toast.remove(), 260);
  }, 3200);
}

export function showModal({
  title = "Confirm action",
  message = "",
  confirmText = "Confirm",
  cancelText = "Cancel",
  fields = [],
  detailsHtml = "",
}) {
  return new Promise((resolve) => {
    const modal = document.createElement("div");
    const hasFields = Array.isArray(fields) && fields.length > 0;
    const fieldsHtml = hasFields
      ? `
        <form class="modal-form" data-modal-form>
          <div class="modal-field-stack">
            ${fields
              .map((field) => {
                if (field.type === "checkbox") {
                  return `
                    <label class="modal-check">
                      <input
                        type="checkbox"
                        name="${escapeHtml(field.name)}"
                        ${field.checked ? "checked" : ""}
                      />
                      <span>
                        <strong>${escapeHtml(field.label || field.name)}</strong>
                        ${field.description ? `<small>${escapeHtml(field.description)}</small>` : ""}
                      </span>
                    </label>
                  `;
                }

                return "";
              })
              .join("")}
          </div>
        </form>
      `
      : "";

    modal.className = "modal-backdrop";
    modal.innerHTML = `
      <div class="modal-card">
        <h3>${escapeHtml(title)}</h3>
        <p>${escapeHtml(message)}</p>
        ${detailsHtml ? `<div class="modal-copy">${detailsHtml}</div>` : ""}
        ${fieldsHtml}
        <div class="modal-actions">
          <button type="button" class="btn btn-ghost" data-modal-cancel>${escapeHtml(cancelText)}</button>
          <button type="button" class="btn btn-primary" data-modal-confirm>${escapeHtml(
            confirmText
          )}</button>
        </div>
      </div>
    `;

    const handleEscape = (event) => {
      if (event.key === "Escape") {
        cleanup(hasFields ? { confirmed: false, values: collectValues() || {} } : false);
      }
    };

    const cleanup = (result) => {
      document.removeEventListener("keydown", handleEscape);
      modal.remove();
      resolve(result);
    };

    const form = modal.querySelector("[data-modal-form]");
    const collectValues = () => {
      if (!hasFields || !form) {
        return null;
      }

      return fields.reduce((values, field) => {
        const control = form.elements.namedItem(field.name);
        if (field.type === "checkbox") {
          values[field.name] = Boolean(control?.checked);
        } else {
          values[field.name] = control?.value ?? "";
        }
        return values;
      }, {});
    };

    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        cleanup(hasFields ? { confirmed: false, values: collectValues() || {} } : false);
      }
    });

    modal
      .querySelector("[data-modal-cancel]")
      .addEventListener("click", () =>
        cleanup(hasFields ? { confirmed: false, values: collectValues() || {} } : false)
      );
    modal.querySelector("[data-modal-confirm]").addEventListener("click", () =>
      cleanup(hasFields ? { confirmed: true, values: collectValues() || {} } : true)
    );

    document.addEventListener("keydown", handleEscape);

    document.body.appendChild(modal);
  });
}

export function renderEmptyState(container, title, description, actionHtml = "") {
  if (!container) {
    return;
  }

  container.innerHTML = `
    <div class="empty-state">
      <h3>${escapeHtml(title)}</h3>
      <p>${escapeHtml(description)}</p>
      ${actionHtml}
    </div>
  `;
}
