import { bootstrapPage } from "../core/shell.js";
import { getEmergencies, subscribeEmergencies } from "../core/store.js";
import { buildShareUrl, copyText, isActiveEmergency } from "../core/utils.js";
import { renderRequestCards } from "../core/renderers.js";
import { showToast } from "../core/ui.js";

document.addEventListener("DOMContentLoaded", async () => {
  const { user } = await bootstrapPage({ currentPage: "tracking-id" });
  const form = document.getElementById("tracking-id-form");
  const currentPanel = document.getElementById("tracking-id-current");

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const formData = new FormData(form);
    const trackingId = String(formData.get("trackingId") || "").trim();

    if (trackingId.length !== 5) {
      showToast("Please enter a valid 5-digit emergency ID.", "error");
      return;
    }

    window.location.href = `live-tracking.html?trackingId=${encodeURIComponent(trackingId)}`;
  });

  if (!user || user.role !== "patient") {
    renderRequestCards(
      currentPanel,
      [],
      user
        ? "Signed-in patients see their active tracking ID here."
        : "Sign in as a patient to view your latest tracking ID automatically."
    );
    return;
  }

  const renderCurrent = (emergencies) => {
    const activeEmergency = emergencies.find(
      (emergency) => emergency.patientId === user.uid && isActiveEmergency(emergency)
    );

    if (!activeEmergency) {
      renderRequestCards(
        currentPanel,
        [],
        "You do not have a live emergency right now. Book an ambulance to generate a tracking ID."
      );
      return;
    }

    const shareUrl = buildShareUrl(activeEmergency.trackingId);
    renderRequestCards(currentPanel, [
      {
        title: `Tracking ID ${activeEmergency.trackingId}`,
        subtitle: `Share this with family for live status updates.`,
        badge: "Live",
        badgeTone: "tone-danger",
        body: `
          <div class="tracking-id-box">
            <span>Active ID</span>
            <strong>${activeEmergency.trackingId}</strong>
          </div>
          <div class="button-row app-note">
            <a class="btn btn-secondary btn-sm" href="live-tracking.html?trackingId=${activeEmergency.trackingId}">Open Live Tracking</a>
            <button class="btn btn-ghost btn-sm" data-copy-share-link="${shareUrl}" type="button">Copy Share Link</button>
          </div>
        `,
      },
    ]);
  };

  renderCurrent(await getEmergencies());
  await subscribeEmergencies(renderCurrent);

  currentPanel.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-copy-share-link]");
    if (!button) {
      return;
    }

    const copied = await copyText(button.dataset.copyShareLink);
    showToast(copied ? "Share link copied." : "Clipboard is unavailable in this browser.", copied ? "success" : "error");
  });
});
