import { useFirebase } from "../firebase-config.js";
import { explainAppError } from "../core/errors.js";
import {
  geocodeCityName,
  reverseGeocodeLocation,
  stringifyCoordinateStorage,
} from "../core/geocoding.js";
import { getBestAvailableLocation } from "../core/location.js";
import { clearDynamicLayers, createMap, fitToPoints, upsertMarker } from "../core/maps.js";
import { renderRequestCards, renderStatCards, renderTableRows } from "../core/renderers.js";
import { bootstrapPage } from "../core/shell.js";
import {
  createManagedAccount,
  resetPassword,
  subscribeEmergencies,
  subscribeUsers,
  updateUser,
} from "../core/store.js";
import {
  capitalizeWords,
  escapeHtml,
  formatDateTime,
  parseLocationInput,
  stringifyLocation,
} from "../core/utils.js";
import { showToast } from "../core/ui.js";

document.addEventListener("DOMContentLoaded", async () => {
  const { user } = await bootstrapPage({
    currentPage: "admin-dashboard",
    requireAuth: true,
    allowedRoles: ["admin"],
  });
  if (!user) {
    return;
  }

  const statsTarget = document.getElementById("admin-stats");
  const emergenciesTarget = document.getElementById("admin-emergencies");
  const usersTable = document.getElementById("admin-users-table");
  const tripsTable = document.getElementById("admin-trips-table");
  const driverForm = document.getElementById("admin-driver-form");
  const hospitalForm = document.getElementById("admin-hospital-form");
  const userEditForm = document.getElementById("admin-user-edit-form");
  const editorEmptyState = document.getElementById("admin-user-editor-empty");
  const credentialNote = document.getElementById("admin-credential-note");
  const resetButton = document.getElementById("admin-send-reset-link");
  const map = createMap("admin-dashboard-map");

  let users = [];
  let emergencies = [];
  let selectedUserId = "";
  let editorLocationFix = null;

  function setFieldValue(id, value) {
    const field = document.getElementById(id);
    if (field) {
      field.value = value ?? "";
    }
  }

  function setRoleEditorState(role) {
    document.getElementById("admin-edit-patient-fields").classList.toggle("hidden", role !== "patient");
    document.getElementById("admin-edit-driver-fields").classList.toggle("hidden", role !== "driver");
    document.getElementById("admin-edit-hospital-fields").classList.toggle("hidden", role !== "hospital");
  }

  function getSelectedUser() {
    return users.find((candidate) => candidate.uid === selectedUserId) || null;
  }

  function focusMapOnUser(candidate) {
    if (!candidate?.location || !map) {
      return;
    }

    fitToPoints(map, [candidate.location], { zoom: 16, maxZoom: 17 });
  }

  function populateEditor(candidate) {
    selectedUserId = candidate?.uid || "";
    editorLocationFix = candidate?.location
      ? {
          ...candidate.location,
          accuracy: Number(candidate.locationAccuracy || 0),
          source: candidate.locationSource || "saved",
        }
      : null;

    if (!candidate) {
      editorEmptyState.classList.remove("hidden");
      userEditForm.classList.add("hidden");
      return;
    }

    editorEmptyState.classList.add("hidden");
    userEditForm.classList.remove("hidden");
    setRoleEditorState(candidate.role);

    setFieldValue("admin-edit-user-id", candidate.uid);
    setFieldValue("admin-edit-name", candidate.name);
    setFieldValue("admin-edit-phone", candidate.phone);
    setFieldValue("admin-edit-email", candidate.email);
    setFieldValue("admin-edit-role", capitalizeWords(candidate.role));
    setFieldValue(
      "admin-edit-location",
      candidate.location ? stringifyLocation(candidate.location).replace(", ", ",") : ""
    );
    setFieldValue(
      "admin-edit-location-label",
      candidate.locationLabel || (candidate.location ? "Saved map point" : "")
    );
    setFieldValue("admin-edit-location-source", candidate.locationSource || "");

    setFieldValue("admin-edit-age", candidate.age);
    setFieldValue("admin-edit-blood-group", candidate.bloodGroup);
    setFieldValue("admin-edit-emergency-contact", candidate.emergencyContact);
    setFieldValue("admin-edit-allergies", candidate.allergies);

    setFieldValue("admin-edit-ambulance-number", candidate.ambulanceNumber);
    setFieldValue("admin-edit-license-number", candidate.licenseNumber);
    setFieldValue("admin-edit-driver-status", candidate.status || "available");
    setFieldValue("admin-edit-hospital-affiliation", candidate.hospitalAffiliation);

    setFieldValue("admin-edit-address", candidate.address);
    setFieldValue("admin-edit-hospital-contact", candidate.emergencyContactNumber);
    setFieldValue("admin-edit-ambulance-count", candidate.ambulanceCount);
    setFieldValue("admin-edit-available-beds", candidate.availableBeds);
    setFieldValue("admin-edit-icu-beds", candidate.icuBeds);

    const emailField = document.getElementById("admin-edit-email");
    emailField.disabled = useFirebase;
    credentialNote.textContent = useFirebase
      ? "Profile details can be edited here. Sign-in email changes need a secure admin backend, and password recovery is sent as a reset email."
      : "Local mode allows direct email editing here. Use the reset button for password recovery.";
    resetButton.disabled = !candidate.email;
  }

  function buildUserRows() {
    const rows = users
      .map((candidate) => {
        const statusOrBeds =
          candidate.role === "driver"
            ? capitalizeWords(candidate.status || "available")
            : candidate.role === "hospital"
              ? `${candidate.availableBeds || 0} beds`
              : candidate.role === "patient"
                ? candidate.phone || "Profile only"
                : "Admin";

        return `
          <tr ${candidate.uid === selectedUserId ? 'class="row-selected"' : ""}>
            <td>${escapeHtml(candidate.name || "Unknown")}</td>
            <td>${escapeHtml(capitalizeWords(candidate.role))}</td>
            <td>${escapeHtml(candidate.email || "n/a")}</td>
            <td>${escapeHtml(statusOrBeds)}</td>
            <td>
              <div class="table-actions">
                <button class="btn btn-ghost btn-sm" type="button" data-edit-user="${escapeHtml(candidate.uid)}">Edit</button>
                <button
                  class="btn btn-secondary btn-sm"
                  type="button"
                  data-locate-user="${escapeHtml(candidate.uid)}"
                  ${candidate.location ? "" : "disabled"}
                >
                  Locate
                </button>
              </div>
            </td>
          </tr>
        `;
      })
      .join("");

    usersTable.innerHTML =
      rows ||
      `
        <tr>
          <td colspan="5">No registered users available.</td>
        </tr>
      `;
  }

  function render() {
    const drivers = users.filter((candidate) => candidate.role === "driver");
    const hospitals = users.filter((candidate) => candidate.role === "hospital");
    const activeEmergencies = emergencies.filter((emergency) => emergency.status !== "completed");
    const completedTrips = emergencies.filter((emergency) => emergency.status === "completed");

    renderStatCards(statsTarget, [
      {
        label: "Active emergencies",
        value: activeEmergencies.length,
        badge: "Live",
        badgeTone: activeEmergencies.length ? "tone-danger" : "tone-success",
        helper: "System-wide open requests",
      },
      {
        label: "Available drivers",
        value: drivers.filter((driver) => driver.status === "available").length,
        helper: "Ambulances ready to dispatch",
      },
      {
        label: "Hospitals",
        value: hospitals.length,
        helper: "Facilities connected to the platform",
      },
    ]);

    renderRequestCards(
      emergenciesTarget,
      emergencies.map((emergency) => ({
        title: `${emergency.patientName || "Patient"} • ${emergency.trackingId}`,
        subtitle: `Driver ${emergency.driverName || "Pending"} • Hospital ${emergency.hospitalName || "Pending"}`,
        badge: emergency.status,
        badgeTone:
          emergency.status === "completed"
            ? "tone-success"
            : emergency.status === "arrived"
              ? "tone-warning"
              : "tone-info",
        body: `
          <div class="key-value-grid">
            <div class="key-value">
              <strong>Traffic</strong>
              <span>${escapeHtml(capitalizeWords(emergency.trafficLevel || "moderate"))}</span>
            </div>
            <div class="key-value">
              <strong>Updated</strong>
              <span>${escapeHtml(formatDateTime(emergency.updatedAt))}</span>
            </div>
          </div>
          <div class="button-row app-note">
            <a class="btn btn-ghost btn-sm" href="live-tracking.html?trackingId=${escapeHtml(emergency.trackingId)}">Open Tracking</a>
          </div>
        `,
      })),
      "Emergency requests will appear once patients begin booking ambulances."
    );

    buildUserRows();

    renderTableRows(
      tripsTable,
      completedTrips
        .map(
          (trip) => `
            <tr>
              <td>${escapeHtml(trip.trackingId)}</td>
              <td>${escapeHtml(trip.patientName || "Patient")}</td>
              <td>${escapeHtml(trip.driverName || "Driver")}</td>
              <td>${escapeHtml(capitalizeWords(trip.status))}</td>
            </tr>
          `
        )
        .join("")
    );

    const selectedUser = getSelectedUser();
    if (selectedUser) {
      populateEditor(selectedUser);
    } else if (selectedUserId) {
      populateEditor(null);
    }

    if (!map) {
      return;
    }

    clearDynamicLayers(map);
    const points = [];

    hospitals.forEach((hospital) => {
      if (!hospital.location) {
        return;
      }

      upsertMarker(map, hospital.uid, hospital.location, {
        label: "H",
        color: "#0f6fff",
        popup: hospital.name,
      });
      points.push(hospital.location);
    });

    drivers.forEach((driver) => {
      if (!driver.location) {
        return;
      }

      upsertMarker(map, driver.uid, driver.location, {
        label: "A",
        color: driver.status === "available" ? "#16a34a" : "#f59e0b",
        popup: `${driver.name} • ${capitalizeWords(driver.status || "available")}`,
      });
      points.push(driver.location);
    });

    activeEmergencies.forEach((emergency) => {
      if (!emergency.patientLocation) {
        return;
      }

      upsertMarker(map, emergency.id, emergency.patientLocation, {
        label: "P",
        color: "#ef4444",
        popup: `${emergency.patientName || "Patient"} • ${emergency.trackingId}`,
      });
      points.push(emergency.patientLocation);
    });

    if (points.length) {
      fitToPoints(map, points);
    }
  }

  async function submitManagedAccount(role, form, successMessage) {
    try {
      await resolveLocationInputs({
        labelField: form.querySelector('[name="locationLabel"]'),
        coordsField: form.querySelector('[name="currentLocation"]'),
      });
      const payload = Object.fromEntries(new FormData(form).entries());
      await createManagedAccount(role, payload);
      form.reset();
      showToast(successMessage, "success");
    } catch (error) {
      showToast(explainAppError(error), "error");
    }
  }

  async function resolveLocationInputs({ labelField, coordsField }) {
    if (!labelField || !coordsField) {
      return;
    }

    const label = labelField.value.trim();
    const hasCoords = coordsField.value.trim();
    if (!label || hasCoords) {
      return;
    }

    const result = await geocodeCityName(label);
    labelField.value = result.label || label;
    coordsField.value = result.currentLocation;
  }

  async function geocodeIntoFields(button) {
    const labelField = document.querySelector(button.dataset.target);
    const coordsField = document.querySelector(button.dataset.coordinates);
    if (!labelField || !coordsField) {
      return;
    }

    const result = await geocodeCityName(labelField.value);
    labelField.value = result.label || labelField.value.trim();
    coordsField.value = result.currentLocation;
    return result;
  }

  async function captureGpsIntoField(button) {
    const labelField = document.querySelector(button.dataset.target);
    const coordsField = document.querySelector(button.dataset.coordinates);
    if (!labelField || !coordsField) {
      return;
    }

    try {
      const locationFix = await getBestAvailableLocation({ warmupTimeoutMs: 28000 });
      const reverse = await reverseGeocodeLocation(locationFix);
      labelField.value = reverse?.label || "Current GPS location";
      coordsField.value = stringifyCoordinateStorage(locationFix);
      const sourceField = document.getElementById("admin-edit-location-source");
      if (coordsField.id === "admin-edit-location") {
        editorLocationFix = locationFix;
        if (sourceField) {
          sourceField.value = locationFix.source || "gps";
        }
      }
      showToast("Location captured from device GPS.", "success");
    } catch (error) {
      showToast(explainAppError(error), "error");
    }
  }

  driverForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    await submitManagedAccount("driver", driverForm, "Driver account created.");
  });

  hospitalForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    await submitManagedAccount("hospital", hospitalForm, "Hospital account created.");
  });

  document.querySelectorAll('input[name="locationLabel"]').forEach((field) => {
    field.addEventListener("input", () => {
      const coordsField = document.querySelector(field.dataset.coordinates || "");
      if (coordsField) {
        coordsField.value = "";
      }
    });
  });

  usersTable.addEventListener("click", (event) => {
    const editButton = event.target.closest("[data-edit-user]");
    if (editButton) {
      const candidate = users.find((item) => item.uid === editButton.dataset.editUser);
      if (candidate) {
        populateEditor(candidate);
        userEditForm.scrollIntoView({ behavior: "smooth", block: "start" });
      }
      return;
    }

    const locateButton = event.target.closest("[data-locate-user]");
    if (locateButton) {
      const candidate = users.find((item) => item.uid === locateButton.dataset.locateUser);
      focusMapOnUser(candidate);
    }
  });

  document.querySelectorAll("[data-find-location]").forEach((button) => {
    button.addEventListener("click", async () => {
      try {
        await geocodeIntoFields(button);
        showToast("City located on the map successfully.", "success");
      } catch (error) {
        showToast(explainAppError(error), "error");
      }
    });
  });

  document.querySelectorAll("[data-capture-location]").forEach((button) => {
    button.addEventListener("click", async () => {
      await captureGpsIntoField(button);
    });
  });

  userEditForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const selectedUser = getSelectedUser();
    if (!selectedUser) {
      showToast("Select a user before saving changes.", "error");
      return;
    }

    try {
      await resolveLocationInputs({
        labelField: document.getElementById("admin-edit-location-label"),
        coordsField: document.getElementById("admin-edit-location"),
      });

      const rawLocation = document.getElementById("admin-edit-location").value.trim();
      const parsedLocation = rawLocation ? parseLocationInput(rawLocation) : null;
      if (rawLocation && !parsedLocation) {
        throw new Error("Enter a valid city or use GPS to fetch the location.");
      }

      const patch = {
        name: document.getElementById("admin-edit-name").value.trim(),
        phone: document.getElementById("admin-edit-phone").value.trim(),
        locationLabel: document.getElementById("admin-edit-location-label").value.trim(),
        location: parsedLocation,
        locationAccuracy: parsedLocation ? Number(editorLocationFix?.accuracy || selectedUser.locationAccuracy || 0) : 0,
        locationSource: parsedLocation
          ? document.getElementById("admin-edit-location-source").value.trim() ||
            editorLocationFix?.source ||
            selectedUser.locationSource ||
            "manual admin update"
          : "",
      };

      if (!useFirebase) {
        patch.email = document.getElementById("admin-edit-email").value.trim();
      }

      if (selectedUser.role === "patient") {
        Object.assign(patch, {
          age: document.getElementById("admin-edit-age").value.trim(),
          bloodGroup: document.getElementById("admin-edit-blood-group").value.trim(),
          emergencyContact: document.getElementById("admin-edit-emergency-contact").value.trim(),
          allergies: document.getElementById("admin-edit-allergies").value.trim(),
        });
      }

      if (selectedUser.role === "driver") {
        Object.assign(patch, {
          ambulanceNumber: document.getElementById("admin-edit-ambulance-number").value.trim(),
          licenseNumber: document.getElementById("admin-edit-license-number").value.trim(),
          status: document.getElementById("admin-edit-driver-status").value,
          hospitalAffiliation: document
            .getElementById("admin-edit-hospital-affiliation")
            .value.trim(),
        });
      }

      if (selectedUser.role === "hospital") {
        Object.assign(patch, {
          address: document.getElementById("admin-edit-address").value.trim(),
          emergencyContactNumber: document
            .getElementById("admin-edit-hospital-contact")
            .value.trim(),
          ambulanceCount: Number(document.getElementById("admin-edit-ambulance-count").value || 0),
          availableBeds: Number(document.getElementById("admin-edit-available-beds").value || 0),
          icuBeds: Number(document.getElementById("admin-edit-icu-beds").value || 0),
        });
      }

      await updateUser(selectedUser.uid, patch);
      showToast("User record updated.", "success");
    } catch (error) {
      showToast(explainAppError(error), "error");
    }
  });

  resetButton.addEventListener("click", async () => {
    const selectedUser = getSelectedUser();
    if (!selectedUser?.email) {
      showToast("This user does not have a recovery email configured.", "error");
      return;
    }

    try {
      await resetPassword(selectedUser.email);
      showToast(`Password reset sent to ${selectedUser.email}.`, "success");
    } catch (error) {
      showToast(explainAppError(error), "error");
    }
  });

  await subscribeUsers((nextUsers) => {
    users = nextUsers;
    render();
  });

  await subscribeEmergencies((nextEmergencies) => {
    emergencies = nextEmergencies;
    render();
  });
});
