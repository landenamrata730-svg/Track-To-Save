export const APP_NAME = "Track2Save";

export const DEFAULT_CENTER = Object.freeze({
  lat: 17.6796,
  lng: 75.3302,
});

export const ROLE_LABELS = Object.freeze({
  admin: "Admin",
  patient: "Patient",
  driver: "Driver",
  hospital: "Hospital",
});

export const DASHBOARD_PATHS = Object.freeze({
  admin: "admin-dashboard.html",
  patient: "patient-dashboard.html",
  driver: "driver-dashboard.html",
  hospital: "hospital-dashboard.html",
});

export const PUBLIC_LINKS = [
  { href: "index.html", label: "Home", key: "home" },
  { href: "tracking-id.html", label: "Track ID", key: "tracking-id" },
  { href: "login.html", label: "Login", key: "login" },
];

export const ROLE_NAV = Object.freeze({
  admin: [
    { href: "admin-dashboard.html", label: "Control Room", key: "admin-dashboard" },
    { href: "profile.html", label: "Profile", key: "profile" },
  ],
  patient: [
    { href: "patient-dashboard.html", label: "Dashboard", key: "patient-dashboard" },
    { href: "book-ambulance.html", label: "Book", key: "book-ambulance" },
    { href: "live-tracking.html", label: "Live Tracking", key: "live-tracking" },
    { href: "profile.html", label: "Profile", key: "profile" },
  ],
  driver: [
    { href: "driver-dashboard.html", label: "Driver Desk", key: "driver-dashboard" },
    { href: "live-tracking.html", label: "Trip View", key: "live-tracking" },
    { href: "profile.html", label: "Profile", key: "profile" },
  ],
  hospital: [
    { href: "hospital-dashboard.html", label: "Hospital Desk", key: "hospital-dashboard" },
    { href: "live-tracking.html", label: "Live Feed", key: "live-tracking" },
    { href: "profile.html", label: "Profile", key: "profile" },
  ],
});

export const DRIVER_STATUSES = [
  "available",
  "on_trip",
  "offline",
  "emergency_mode",
];

export const EMERGENCY_STATUSES = [
  "assigned",
  "en_route",
  "arrived",
  "completed",
];

export const TRAFFIC_LEVELS = Object.freeze({
  low: {
    label: "Smooth Traffic",
    speedKmh: 42,
    color: "#22c55e",
  },
  moderate: {
    label: "Moderate Traffic",
    speedKmh: 28,
    color: "#f59e0b",
  },
  heavy: {
    label: "Heavy Congestion",
    speedKmh: 16,
    color: "#ef4444",
  },
});

export const MAP_TILE_URL = "https://tile.openstreetmap.org/{z}/{x}/{y}.png";
export const MAP_TILE_ATTRIBUTION =
  '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

export const ACTIVE_EMERGENCY_STATUSES = ["assigned", "en_route", "arrived"];
